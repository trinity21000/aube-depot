"""Aube Linux : moteur d'IA commun, sur le NPU Intel (OpenVINO).

Un seul service par session garde les modèles chargés et les prête aux
applications, au lieu que chacune charge le sien : la dictée partout répond
tout de suite, et la mémoire n'est occupée qu'une fois. Rien ne sort de
l'ordinateur. Lancé à l'ouverture de session avec le Python d'OpenVINO :

    /opt/aube/openvino/bin/python3 -I /usr/lib/aube/aube-ia.py

Prise : $XDG_RUNTIME_DIR/aube-ia.sock (accessible au seul compte). Une
requête JSON par ligne, une réponse JSON par ligne :
    {"op": "etat"}                                → modèles chargés
    {"op": "transcrire", "audio": chemin, "langue": "fr"} → {"texte": …}
    {"op": "chercher", "texte": "un chat sur un canapé", "n": 60, "dossier": …}
        → {"resultats": [[chemin, score], …], "index": {progression}}
    {"op": "indexer", "dossiers": [chemins]}      → indexation en arrière-plan
    {"op": "photo", …requête de photo-moteur…}     → retouches et IA de Photo
    {"op": "assistant", "outils": [...]}           → la connexion devient une
        conversation (même dialogue que assistant-moteur.py), jusqu'à sa fermeture
Modèles chargés à la demande ; Whisper (dictée) l'est dès le démarrage et
reste en mémoire, les autres sont libérés après INACTIF secondes sans usage.
Le NPU est préféré, le processeur prend le relais.
"""
import json, os, signal, socketserver, subprocess, sys, threading, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

CACHE = os.path.expanduser('~/.cache/aube')
INACTIF = 600
PRISE = os.path.join(os.environ.get('XDG_RUNTIME_DIR') or '/tmp', 'aube-ia.sock')

# nom → (dossier du modèle, cache de compilation, garder en mémoire)
MODELES = {
    'whisper': (os.path.join(CACHE, 'dictee', 'whisper-large-v3-turbo-int8-ov'),
                os.path.join(CACHE, 'dictee', 'cache-npu'), True),
    'clip': (os.path.join(CACHE, 'recherche'), None, False),
    'qwen': (os.path.join(CACHE, 'assistant', 'Qwen3-8B-int4-cw-ov'),
             os.path.join(CACHE, 'assistant', 'cache-npu'), False),
    'photo': (os.path.join(CACHE, 'photo'), os.path.join(CACHE, 'photo', 'cache'), False),
}


def module(nom, fichier):
    """Charge un moteur d'Aube (nom de fichier avec tiret) comme module."""
    if nom not in sys.modules:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            nom, os.path.join(os.path.dirname(os.path.abspath(__file__)), fichier))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        sys.modules[nom] = m
    return sys.modules[nom]


def journal(*a):
    print(time.strftime('%H:%M:%S'), *a, file=sys.stderr, flush=True)


class Modele:
    def __init__(self, nom):
        self.nom = nom
        self.dossier, self.cache, self.garder = MODELES[nom]
        self.pipe = None
        self.appareil = None
        self.verrou = threading.Lock()   # une requête à la fois par modèle
        self.dernier = 0.0
        self.sessions = 0                # conversations ouvertes (Assistant)

    def present(self):
        return os.path.isfile(os.path.join(self.dossier, '.verifie'))

    def charger(self, dire=None):
        """À appeler sous self.verrou."""
        if self.pipe is not None:
            return
        if self.nom == 'photo':
            # Les modèles de Photo se compilent un par un au premier usage.
            module('photo_moteur', 'photo-moteur.py')
            self.pipe, self.appareil = True, 'NPU/CPU'
            return
        if self.nom == 'qwen':
            if not self.present():
                raise RuntimeError('modèle de l\'Assistant absent : ouvrez l\'Assistant pour le télécharger')
            self.pipe, self.appareil = module('assistant_moteur', 'assistant-moteur.py').charger(
                self.dossier, self.cache, dire or (lambda **kw: None))
            if self.pipe is None:
                raise RuntimeError('le modèle ne se charge ni sur le NPU ni sur le processeur')
            journal('qwen chargé sur', self.appareil)
            return
        if not self.present():
            raise RuntimeError('modèle %s absent : ouvrez une fois l\'application qui le '
                               'télécharge (%s)' % (self.nom, {'clip': 'Photo › Rechercher'}.get(
                                   self.nom, 'Dictée')))
        import openvino as ov
        import openvino_genai as g
        erreurs = []
        for dev in (['NPU'] if 'NPU' in ov.Core().available_devices else []) + ['CPU']:
            try:
                t0 = time.perf_counter()
                if self.nom == 'whisper':
                    self.pipe = g.WhisperPipeline(self.dossier, dev, CACHE_DIR=self.cache)
                elif self.nom == 'clip':
                    import aube_clip
                    self.pipe = aube_clip.Clip(dev)
                self.appareil = dev
                journal('%s chargé sur %s en %.1f s' % (self.nom, dev, time.perf_counter() - t0))
                return
            except Exception as e:
                erreurs.append('%s : %s' % (dev, str(e)[:200]))
        raise RuntimeError('%s ne se charge pas (%s)' % (self.nom, ' ; '.join(erreurs)))

    def liberer_si_inactif(self):
        if self.garder or self.pipe is None or self.sessions or time.time() - self.dernier < INACTIF:
            return
        with self.verrou:
            if self.pipe is not None and not self.sessions and time.time() - self.dernier >= INACTIF:
                if self.nom == 'photo':
                    sys.modules['photo_moteur'].liberer()
                self.pipe = None
                import gc
                gc.collect()
                journal('%s libéré (inactif)' % self.nom)


MOD = {n: Modele(n) for n in MODELES}


def lire_audio(chemin):
    """N'importe quel fichier audio → 16 kHz mono, float32 (ffmpeg)."""
    import numpy as np
    brut = subprocess.run(
        ['ffmpeg', '-nostdin', '-v', 'error', '-i', chemin, '-vn', '-ac', '1', '-ar', '16000',
         '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(brut, dtype=np.float32)


def transcrire(req):
    audio = lire_audio(req['audio'])
    if audio.size < 1600:
        return {'texte': ''}
    # Sur du silence, Whisper invente (« Sous-titrage Société Radio-Canada »).
    if float(abs(audio).max()) < 0.003:
        return {'erreur': 'aucun son capté (micro coupé ou absent ?)'}
    m = MOD['whisper']
    with m.verrou:
        m.charger()
        t0 = time.perf_counter()
        r = m.pipe.generate(audio.tolist(), language='<|%s|>' % req.get('langue', 'fr'),
                            task='transcribe')
        m.dernier = time.time()
    return {'texte': str(r).strip(), 'appareil': m.appareil,
            'duree_audio': round(audio.size / 16000, 1), 'duree': round(time.perf_counter() - t0, 2)}


_INDEX = None


def index():
    global _INDEX
    if _INDEX is None:
        import aube_clip
        _INDEX = aube_clip.Index()
    return _INDEX


def clip_pret():
    """Modèle CLIP chargé (gardé en vie tant qu'on s'en sert)."""
    m = MOD['clip']
    with m.verrou:
        m.charger()
        m.dernier = time.time()
        return m.pipe


def dossier_images():
    try:
        r = subprocess.run(['xdg-user-dir', 'PICTURES'], capture_output=True, text=True).stdout.strip()
    except OSError:
        r = ''
    return r if r and r != os.path.expanduser('~') else os.path.expanduser('~/Images')


def indexer(req):
    if not MOD['clip'].present():
        return {'erreur': 'modèle de recherche absent'}
    dossiers = [d for d in req.get('dossiers') or [dossier_images()] if os.path.isdir(d)]

    def tache():
        # Indexation en priorité basse : la dictée et le bureau restent fluides.
        try:
            os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 15)
        except OSError:
            pass
        try:
            index().mettre_a_jour(dossiers, clip_pret)
        except Exception as e:
            journal('indexation :', e)
    if not index().progres['en_cours']:
        threading.Thread(target=tache, daemon=True).start()
    return {'index': index().progres}


def chercher(req):
    texte = (req.get('texte') or '').strip()
    if not texte:
        return {'erreur': 'description vide'}
    if not MOD['clip'].present():
        return {'erreur': 'modèle de recherche absent'}
    m = MOD['clip']
    with m.verrou:
        m.charger()
        v = m.pipe.vecteur_texte(texte)
        m.dernier = time.time()
    resultats = index().chercher(v, int(req.get('n', 60)), req.get('dossier'))
    # Photos ajoutées depuis : mises à jour en arrière-plan pour la fois suivante.
    indexer({})
    return {'resultats': resultats, 'index': index().progres, 'indexees': len(index().chemins)}


def photo(req):
    m = MOD['photo']
    with m.verrou:
        m.charger()
        r = sys.modules['photo_moteur'].traiter(req.get('requete', {}))
        m.dernier = time.time()
    return r


def assistant(req, lire, dire):
    """Conversation de l'Assistant sur cette connexion, jusqu'à sa fermeture."""
    m = MOD['qwen']
    m.sessions += 1
    try:
        with m.verrou:
            m.charger(dire)
        pret = m.pipe

        def lire_et_garder():
            ligne = lire()
            m.dernier = time.time()
            return ligne
        # Verrou du modèle pris pendant chaque génération seulement : deux
        # fenêtres de l'Assistant peuvent rester ouvertes.
        module('assistant_moteur', 'assistant-moteur.py').servir(
            pret, m.appareil, req.get('outils') or [], lire_et_garder, dire, m.verrou)
    except Exception as e:
        dire(etat='erreur', erreur=str(e)[:300])
    finally:
        m.sessions -= 1
        m.dernier = time.time()


def charger(req):
    m = MOD.get(req.get('modele'))
    if m is None:
        return {'erreur': 'modèle inconnu'}
    with m.verrou:
        m.charger()
        m.dernier = time.time()
    return {'charge': True, 'appareil': m.appareil}


def etat(_req):
    r = {'modeles': {n: {'charge': m.pipe is not None, 'appareil': m.appareil,
                         'present': m.present()} for n, m in MOD.items()}}
    if _INDEX is not None:
        r['index'] = dict(_INDEX.progres, indexees=len(_INDEX.chemins))
    return r


OPERATIONS = {'transcrire': transcrire, 'etat': etat, 'chercher': chercher, 'indexer': indexer,
              'photo': photo, 'charger': charger}


class Requete(socketserver.StreamRequestHandler):
    def handle(self):
        for ligne in self.rfile:
            try:
                req = json.loads(ligne)
                if req.get('op') == 'assistant':
                    def dire(**kw):
                        self.wfile.write((json.dumps(kw, ensure_ascii=False) + '\n').encode())
                        self.wfile.flush()
                    assistant(req, lambda: self.rfile.readline().decode(), dire)
                    return
                rep = OPERATIONS[req.get('op')](req)
            except KeyError:
                rep = {'erreur': 'opération inconnue'}
            except subprocess.CalledProcessError as e:
                rep = {'erreur': 'fichier illisible : ' + e.stderr.decode(errors='replace')[:200]}
            except Exception as e:
                rep = {'erreur': str(e)[:300]}
            self.wfile.write((json.dumps(rep, ensure_ascii=False) + '\n').encode())
            self.wfile.flush()


class Serveur(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True


def entretien():
    while True:
        time.sleep(60)
        for m in MOD.values():
            m.liberer_si_inactif()


def prechargement():
    for m in MOD.values():
        if m.garder and m.present():
            try:
                with m.verrou:
                    m.charger()
            except Exception as e:
                journal(e)


def main():
    if os.path.exists(PRISE):
        try:   # un autre service répond déjà : rien à faire
            import socket
            s = socket.socket(socket.AF_UNIX)
            s.connect(PRISE)
            s.close()
            journal('déjà lancé')
            return 0
        except OSError:
            os.unlink(PRISE)
    # Arrêt (fin de session, kill) : la prise est retirée proprement.
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    ancien = os.umask(0o077)
    serveur = Serveur(PRISE, Requete)
    os.umask(ancien)
    threading.Thread(target=entretien, daemon=True).start()
    threading.Thread(target=prechargement, daemon=True).start()
    if MOD['clip'].present():
        # Photos nouvelles depuis la dernière session : indexées sans attendre.
        threading.Timer(120, indexer, args=({},)).start()
    journal('prêt sur', PRISE)
    try:
        serveur.serve_forever()
    finally:
        try:
            os.unlink(PRISE)
        except OSError:
            pass
    return 0


if __name__ == '__main__':
    sys.exit(main())
