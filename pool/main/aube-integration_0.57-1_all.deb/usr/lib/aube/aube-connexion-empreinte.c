/*
 * Aube Linux : ouvrir la session dès que l'empreinte est reconnue.
 *
 * lightdm-gtk-greeter (2.0.9) n'ouvre la session tout seul qu'après une
 * question de PAM (mot de passe). Avec l'empreinte, PAM ne pose pas de
 * question : l'écran de connexion attend alors un clic sur « Se connecter ».
 * Ce module, chargé dans l'écran de connexion seulement (LD_PRELOAD, voir
 * /usr/share/xgreeters/aube-greeter.desktop), observe trois fonctions de
 * liblightdm-gobject :
 *   - lightdm_greeter_authenticate : début d'une authentification ;
 *   - lightdm_greeter_respond      : réponse à une question (mot de passe) ;
 *   - lightdm_greeter_get_is_authenticated : quand elle répond « oui » sans
 *     qu'aucune réponse n'ait été donnée, c'est l'empreinte : la session est
 *     ouverte aussitôt (session par défaut du compte), une seule fois.
 * Avec un mot de passe, rien ne change (l'écran l'ouvre lui-même).
 *
 * Compilé par le correctif 0.42 : tcc -shared -fPIC -nostdlib -o … aube-connexion-empreinte.c
 */
/* Sans en-têtes ni bibliothèques à l'édition des liens (tcc seul suffit) :
 * dlsym est trouvé à l'exécution dans la libc de l'écran de connexion. */
extern void *dlsym(void *module, const char *nom);
#define RTLD_NEXT ((void *) -1l)
#define NULL ((void *) 0)

typedef void Greeter;
typedef void Erreur;
typedef int (*f_auth)(Greeter *, const char *, Erreur **);
typedef int (*f_rep)(Greeter *, const char *, Erreur **);
typedef int (*f_ok)(Greeter *);
typedef int (*f_session)(Greeter *, const char *, Erreur **);

static int repondu = 0;   /* une question a reçu une réponse */
static int lance = 0;     /* session déjà demandée par ce module */

int lightdm_greeter_authenticate(Greeter *g, const char *nom, Erreur **e)
{
    static f_auth vrai = NULL;
    if (!vrai)
        vrai = (f_auth) dlsym(RTLD_NEXT, "lightdm_greeter_authenticate");
    repondu = 0;
    lance = 0;
    return vrai ? vrai(g, nom, e) : 0;
}

int lightdm_greeter_respond(Greeter *g, const char *reponse, Erreur **e)
{
    static f_rep vrai = NULL;
    if (!vrai)
        vrai = (f_rep) dlsym(RTLD_NEXT, "lightdm_greeter_respond");
    repondu = 1;
    return vrai ? vrai(g, reponse, e) : 0;
}

int lightdm_greeter_get_is_authenticated(Greeter *g)
{
    static f_ok vrai = NULL;
    static f_session session = NULL;
    int r;
    if (!vrai)
        vrai = (f_ok) dlsym(RTLD_NEXT, "lightdm_greeter_get_is_authenticated");
    if (!session)
        session = (f_session) dlsym(RTLD_NEXT, "lightdm_greeter_start_session_sync");
    r = vrai ? vrai(g) : 0;
    if (r && !repondu && !lance && session) {
        lance = 1;
        session(g, NULL, NULL);   /* NULL : session par défaut (Xfce) */
    }
    return r;
}
