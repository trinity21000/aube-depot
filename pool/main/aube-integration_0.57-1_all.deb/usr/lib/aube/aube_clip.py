"""Aube Linux : recherche de photos par description (CLIP, OpenVINO).

Côté image : CLIP ViT-B/32 (Xenova/clip-vit-base-patch32, ONNX fp16), sur le
NPU. Côté texte : clip-ViT-B-32-multilingual-v1 (sentence-transformers,
OpenVINO int8), qui place une phrase de 50 langues, dont le français, au même
endroit que les images qui lui ressemblent. Sur le processeur (une phrase).

Index : ~/.cache/aube/recherche/index.sqlite (chemin, date, vecteur 512
float16). Mis à jour par morceaux : seules les photos nouvelles ou modifiées
sont calculées. Utilisé par aube-ia.py (Python d'OpenVINO).
"""
import json, os, re, sqlite3, struct, threading, time, unicodedata

import numpy as np

DOSSIER = os.path.expanduser('~/.cache/aube/recherche')
INDEX = os.path.join(DOSSIER, 'index.sqlite')
TEXTE = os.path.join(DOSSIER, 'texte')
IMAGE = os.path.join(DOSSIER, 'image')
EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tif', '.tiff', '.gif')
LOT = 8           # images par passage sur le NPU
MOYENNE = np.array([0.48145466, 0.4578275, 0.40821073], np.float32).reshape(3, 1, 1)
ECART = np.array([0.26862954, 0.26130258, 0.27577711], np.float32).reshape(3, 1, 1)


def present():
    return os.path.isfile(os.path.join(DOSSIER, '.verifie'))


# ------------------------------------------------------------ jetons (texte)

class WordPiece:
    """Découpage BERT « cased » (do_lower_case = false) + WordPiece."""

    def __init__(self, vocab):
        self.ids = {}
        with open(vocab, encoding='utf-8') as f:
            for i, mot in enumerate(f):
                self.ids[mot.rstrip('\n')] = i

    @staticmethod
    def _ponctuation(c):
        o = ord(c)
        if 33 <= o <= 47 or 58 <= o <= 64 or 91 <= o <= 96 or 123 <= o <= 126:
            return True
        return unicodedata.category(c).startswith('P')

    @staticmethod
    def _cjk(o):
        return (0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF or 0x20000 <= o <= 0x2A6DF
                or 0xF900 <= o <= 0xFAFF or 0x2F800 <= o <= 0x2FA1F)

    def mots(self, texte):
        propre = []
        for c in texte:
            o = ord(c)
            if o == 0 or o == 0xFFFD or unicodedata.category(c) in ('Cc', 'Cf') and c not in '\t\n\r':
                continue
            if c.isspace():
                propre.append(' ')
            elif self._cjk(o) or self._ponctuation(c):
                propre.append(' %s ' % c)
            else:
                propre.append(c)
        return ''.join(propre).split()

    def encoder(self, texte, longueur=64):
        ids = [self.ids['[CLS]']]
        for mot in self.mots(texte):
            debut, morceaux = 0, []
            while debut < len(mot):
                fin = len(mot)
                trouve = None
                while debut < fin:
                    sous = ('##' if debut else '') + mot[debut:fin]
                    if sous in self.ids:
                        trouve = self.ids[sous]
                        break
                    fin -= 1
                if trouve is None:
                    morceaux = [self.ids['[UNK]']]
                    break
                morceaux.append(trouve)
                debut = fin
            ids.extend(morceaux)
        ids = ids[:longueur - 1] + [self.ids['[SEP]']]
        return np.array([ids], np.int64), np.ones((1, len(ids)), np.int64)


def lire_safetensors(chemin):
    with open(chemin, 'rb') as f:
        n = struct.unpack('<Q', f.read(8))[0]
        entete = json.loads(f.read(n))
        donnees = f.read()
    sortie = {}
    for nom, info in entete.items():
        if nom == '__metadata__':
            continue
        a, b = info['data_offsets']
        type_ = {'F32': np.float32, 'F16': np.float16}[info['dtype']]
        sortie[nom] = np.frombuffer(donnees[a:b], type_).reshape(info['shape']).astype(np.float32)
    return sortie


def image_vers_tableau(chemin):
    """Prétraitement CLIP : côté court à 224 (bicubique), centre 224×224."""
    from PIL import Image, ImageOps
    with Image.open(chemin) as im:
        im.draft('RGB', (448, 448))          # JPEG : décodage réduit, bien plus rapide
        im = ImageOps.exif_transpose(im).convert('RGB')
        w, h = im.size
        k = 224 / min(w, h)
        im = im.resize((max(224, round(w * k)), max(224, round(h * k))), Image.BICUBIC)
        w, h = im.size
        g, t = (w - 224) // 2, (h - 224) // 2
        im = im.crop((g, t, g + 224, t + 224))
        a = np.asarray(im, np.float32).transpose(2, 0, 1) / 255.0
    return (a - MOYENNE) / ECART


class Clip:
    def __init__(self, dispositif_image):
        import openvino as ov
        core = ov.Core()
        self.jetons = WordPiece(os.path.join(TEXTE, 'vocab.txt'))
        self.texte = core.compile_model(os.path.join(TEXTE, 'openvino_model_qint8_quantized.xml'), 'CPU')
        self.dense = lire_safetensors(os.path.join(TEXTE, '2_Dense', 'model.safetensors'))['linear.weight']
        m = core.read_model(os.path.join(IMAGE, 'vision_model_fp16.onnx'))
        m.reshape({m.inputs[0].get_any_name(): [LOT, 3, 224, 224]})   # forme fixe pour le NPU
        self.image = core.compile_model(m, dispositif_image)
        self.sortie_image = next((o for o in self.image.outputs if 'image_embeds' in o.get_names()),
                                 self.image.outputs[0])
        self.appareil = dispositif_image

    def vecteur_texte(self, phrase):
        ids, masque = self.jetons.encoder(phrase)
        entrees = {}
        for e in self.texte.inputs:
            nom = e.get_any_name()
            entrees[nom] = ids if 'input_ids' in nom else masque
        h = self.texte(entrees)[self.texte.outputs[0]]        # [1, L, 768]
        moyenne = (h * masque[..., None]).sum(1) / masque.sum()
        v = moyenne @ self.dense.T                             # [1, 512]
        return (v / np.linalg.norm(v)).astype(np.float32)[0]

    def vecteurs_images(self, tableaux):
        n = len(tableaux)
        lot = np.zeros((LOT, 3, 224, 224), np.float32)
        lot[:n] = np.stack(tableaux)
        v = self.image(lot)[self.sortie_image][:n]
        return (v / np.linalg.norm(v, axis=1, keepdims=True)).astype(np.float16)


class Index:
    """Index des photos, mis à jour par morceaux dans un fil à part."""

    def __init__(self):
        os.makedirs(DOSSIER, exist_ok=True)
        self.verrou = threading.Lock()
        with self._base() as b:
            b.execute('CREATE TABLE IF NOT EXISTS photos (chemin TEXT PRIMARY KEY, date REAL, vecteur BLOB)')
        self.chemins, self.matrice = [], np.zeros((0, 512), np.float16)
        self.progres = {'en_cours': False, 'faites': 0, 'a_faire': 0, 'dossiers': []}
        self.recharger()

    def _base(self):
        return sqlite3.connect(INDEX, timeout=30)

    def recharger(self):
        with self._base() as b:
            lignes = b.execute('SELECT chemin, vecteur FROM photos').fetchall()
        chemins = [c for c, _ in lignes]
        matrice = (np.frombuffer(b''.join(v for _, v in lignes), np.float16).reshape(-1, 512)
                   if lignes else np.zeros((0, 512), np.float16))
        with self.verrou:
            self.chemins, self.matrice = chemins, matrice

    @staticmethod
    def lister(dossiers):
        trouves = {}
        for d in dossiers:
            for racine, sous, fichiers in os.walk(d):
                sous[:] = [s for s in sous if not s.startswith('.')]
                for f in fichiers:
                    if f.lower().endswith(EXTENSIONS) and not f.startswith('.'):
                        c = os.path.join(racine, f)
                        try:
                            trouves[c] = os.stat(c).st_mtime
                        except OSError:
                            pass
        return trouves

    def mettre_a_jour(self, dossiers, obtenir_clip):
        """Calcule les photos nouvelles ou modifiées, retire les disparues."""
        if self.progres['en_cours']:
            return
        self.progres.update(en_cours=True, faites=0, a_faire=0, dossiers=list(dossiers))
        try:
            trouves = self.lister(dossiers)
            with self._base() as b:
                connus = dict(b.execute('SELECT chemin, date FROM photos').fetchall())
                dedans = lambda c: any(c.startswith(os.path.join(d, '')) for d in dossiers)
                partis = [c for c in connus if dedans(c) and c not in trouves]
                b.executemany('DELETE FROM photos WHERE chemin = ?', [(c,) for c in partis])
            a_faire = [c for c, t in trouves.items() if connus.get(c) != t]
            self.progres['a_faire'] = len(a_faire)
            if a_faire:
                for i in range(0, len(a_faire), LOT):
                    morceau, tableaux = [], []
                    for c in a_faire[i:i + LOT]:
                        try:
                            tableaux.append(image_vers_tableau(c))
                            morceau.append(c)
                        except Exception:
                            pass                     # image illisible : ignorée
                    if morceau:
                        v = obtenir_clip().vecteurs_images(tableaux)
                        with self._base() as b:
                            b.executemany('INSERT OR REPLACE INTO photos VALUES (?, ?, ?)',
                                          [(c, trouves[c], v[j].tobytes()) for j, c in enumerate(morceau)])
                    self.progres['faites'] = min(i + LOT, len(a_faire))
                    if (i // LOT) % 250 == 0:
                        self.recharger()             # résultats utilisables pendant l'indexation
            if a_faire or partis:
                self.recharger()
        finally:
            self.progres['en_cours'] = False

    def chercher(self, vecteur, n=60, dossier=None):
        with self.verrou:
            chemins, matrice = self.chemins, self.matrice
        if not chemins:
            return []
        scores = matrice.astype(np.float32) @ vecteur
        if dossier:
            pref = os.path.join(dossier, '')
            scores = np.where([c.startswith(pref) for c in chemins], scores, -1.0)
        ordre = np.argsort(-scores)[:n]
        return [(chemins[i], round(float(scores[i]), 4)) for i in ordre if scores[i] > -1]
