"""Moteur de l'Assistant d'Aube : modèle de langage (OpenVINO GenAI) sur le NPU.

Lancé par aube-assistant avec le Python d'OpenVINO (/opt/aube/openvino) :
    python3 -I assistant-moteur.py MODELE CACHE [OUTILS.json]
Lignes JSON : il annonce {"etat": "pret", "appareil": ...} ; pour chaque
{"message": texte} il renvoie la réponse morceau par morceau ({"morceau": …})
puis {"fin": true, "jetons_s": …} ; {"nouveau": true} efface la conversation.
Avec OUTILS.json (actions permises, format « tools »), le modèle peut demander
une action : le moteur envoie {"action": {"nom", "arguments"}} et attend
{"resultat": texte}, que la fenêtre affiche comme réponse ; c'est la fenêtre
qui vérifie et exécute, jamais le moteur. NPU préféré, processeur sinon.
"""
import json, re, sys, time

SYSTEME = ("Tu es l'assistant d'Aube Linux. Tu réponds en français, de façon claire, "
           "exacte et concise, sauf si l'utilisateur écrit dans une autre langue. "
           "Si tu ne sais pas, dis-le.")
SYSTEME_OUTILS = (" Tu peux agir sur l'ordinateur avec les outils fournis, seulement quand "
                  "l'utilisateur le demande : appelle alors l'outil tout de suite, sans "
                  "annoncer ce que tu vas faire. Pour une question sur la batterie, le Wi-Fi, "
                  "le volume, la luminosité, la mémoire vive, le processeur, sa température "
                  "ou l'espace disque, appelle etat_systeme. "
                  "Pour une demande hors de ces outils, explique comment la faire soi-même.")
INFOS = ('etat_systeme',)  # lectures : le modèle répond ensuite à la question
GARDER = 12  # messages gardés en mémoire (en plus des consignes)
APPEL = re.compile(r'<tool_call>\s*(.*?)\s*</tool_call>', re.S)


def dire(**kw):
    print(json.dumps(kw, ensure_ascii=False), flush=True)


class Filtre:
    """Retire du flux affiché la réflexion (<think>) et les appels d'outils."""
    BALISES = {'<think>': '</think>', '<tool_call>': '</tool_call>'}

    def __init__(self, dire=None):
        self.dire = dire or globals()['dire']
        self.n = 0
        self.fin = None   # balise fermante attendue, ou None
        self.tampon = ''

    def __call__(self, morceau):
        self.n += 1
        t = self.tampon + morceau
        self.tampon = ''
        while t:
            if self.fin:
                k = t.find(self.fin)
                if k < 0:
                    self.tampon = t[-len(self.fin):]
                    return False
                t = t[k + len(self.fin):].lstrip('\n')
                self.fin = None
                continue
            k, ouvre = min(((t.find(b), b) for b in self.BALISES if b in t), default=(-1, None))
            if ouvre is None:
                i = t.rfind('<')
                if i >= 0 and len(t) - i < 12:   # peut-être le début d'une balise
                    self.tampon, t = t[i:], t[:i]
                if t:
                    self.dire(morceau=t)
                return False
            if t[:k]:
                self.dire(morceau=t[:k])
            self.fin = self.BALISES[ouvre]
            t = t[k + len(ouvre):]
        return False

    def vider(self):
        if self.tampon and not self.fin:
            self.dire(morceau=self.tampon)
        self.tampon = ''


def appels(texte):
    for bloc in APPEL.findall(texte):
        try:
            a = json.loads(bloc)
        except ValueError:
            continue
        args = a.get('arguments', {})
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except ValueError:
                args = {}
        if a.get('name'):
            yield a['name'], args


def charger(modele, cache, dire):
    """LLMPipeline sur le NPU (processeur sinon) ; (pipe, appareil) ou (None, None)."""
    import openvino as ov
    import openvino_genai as g
    for dev in (['NPU'] if 'NPU' in ov.Core().available_devices else []) + ['CPU']:
        dire(etat='chargement', appareil=dev)
        try:
            t0 = time.perf_counter()
            opts = {'CACHE_DIR': cache}
            if dev == 'NPU':
                # Longueurs fixées à la compilation pour le NPU.
                opts.update(MAX_PROMPT_LEN=4096, MIN_RESPONSE_LEN=1024)
            pipe = g.LLMPipeline(modele, dev, **opts)
            dire(etat='charge', appareil=dev, duree=round(time.perf_counter() - t0, 1))
            return pipe, dev
        except Exception as e:
            dire(etat='echec-appareil', appareil=dev, erreur=str(e)[:300])
    return None, None


def servir(pipe, appareil, outils, lire, dire, verrou=None):
    """Conversation : une requête par ligne lue avec lire(), réponses par
    dire(). Utilisé seul (stdin/stdout) ou par le moteur commun aube-ia
    (prise UNIX, verrou partagé entre fenêtres)."""
    import contextlib
    import openvino_genai as g
    verrou = verrou or contextlib.nullcontext()
    dire(etat='pret', appareil=appareil, actions=len(outils))
    cfg = pipe.get_generation_config()
    cfg.max_new_tokens = 1024
    cfg.do_sample = True
    cfg.temperature = 0.7
    cfg.top_p = 0.8
    cfg.top_k = 20
    cfg.repetition_penalty = 1.05

    def nouvelle():
        h = g.ChatHistory([{'role': 'system', 'content': SYSTEME + (SYSTEME_OUTILS if outils else '')}])
        if outils:
            h.set_tools(outils)
        return h

    def generer(hist, f):
        with verrou:
            return pipe.generate(hist, cfg, f)

    hist = nouvelle()
    while True:
        ligne = lire()
        if not ligne:
            break
        try:
            req = json.loads(ligne)
        except ValueError:
            continue
        if req.get('nouveau'):
            hist = nouvelle()
            dire(etat='nouveau')
            continue
        texte = req.get('message', '').strip()
        if not texte:
            continue
        # Le NPU limite la longueur du contexte : on oublie les plus anciens
        # échanges (en repartant d'une vraie question) plutôt que d'échouer.
        msgs = hist.get_messages()
        if len(msgs) > GARDER + 1:
            garde = msgs[-GARDER:]
            while garde and not (garde[0]['role'] == 'user'
                                 and not garde[0]['content'].startswith('<tool_response>')):
                garde = garde[1:]
            hist.set_messages([msgs[0]] + garde)
        # « /no_think » : réponse directe (Qwen3), plus rapide.
        hist.append({'role': 'user', 'content': texte + ' /no_think'})
        try:
            t0, n = time.perf_counter(), 0
            f = Filtre(dire)
            res = generer(hist, f)
            f.vider()
            n = f.n
            brut = res.texts[0]
            hist.append({'role': 'assistant', 'content': brut})
            resultats, lecture = [], False
            for nom, args in appels(brut):
                dire(action={'nom': nom, 'arguments': args})
                r = json.loads(lire() or '{}')
                resultats.append(str(r.get('resultat', 'pas de réponse')))
                lecture = lecture or nom in INFOS
            if resultats and lecture:
                # Une lecture (état du PC) : le modèle répond à la question
                # posée avec ces valeurs, au lieu de tout réciter.
                hist.append({'role': 'user', 'content': '\n'.join(
                    '<tool_response>\n%s\n</tool_response>' % x for x in resultats) + ' /no_think'})
                f = Filtre(dire)
                res = generer(hist, f)
                f.vider()
                n += f.n
                hist.append({'role': 'assistant', 'content': res.texts[0]})
            elif resultats:
                # Le message de l'action sert de réponse : pas de seconde
                # génération (deux fois plus rapide). Le pipeline du NPU
                # n'accepte qu'un tour « user » avant de générer : le résultat y
                # est rendu comme le fait le gabarit de Qwen3 pour un message
                # « tool » (<tool_response> dans un tour user).
                hist.append({'role': 'user', 'content': '\n'.join(
                    '<tool_response>\n%s\n</tool_response>' % x for x in resultats)})
                hist.append({'role': 'assistant', 'content': ' '.join(resultats)})
            d = time.perf_counter() - t0
            dire(fin=True, jetons_s=round(n / d, 1) if d else 0, appareil=appareil)
        except Exception as e:
            msg = str(e)
            if 'MAX_PROMPT_LEN' in msg or 'prompt' in msg.lower():
                hist = nouvelle()
                dire(erreur='conversation trop longue : elle a été recommencée, reposez la question')
            else:
                dire(erreur=msg[:300])


def main():
    modele, cache = sys.argv[1], sys.argv[2]
    outils = json.load(open(sys.argv[3])) if len(sys.argv) > 3 else []
    pipe, appareil = charger(modele, cache, dire)
    if pipe is None:
        dire(etat='erreur', erreur="le modèle ne se charge ni sur le NPU ni sur le processeur")
        return 1
    servir(pipe, appareil, outils, sys.stdin.readline, dire)
    return 0


if __name__ == '__main__':
    sys.exit(main())
