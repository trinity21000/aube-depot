#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""aube-windows : lanceur français de programmes Windows pour Aube Linux.

S'appuie sur Bottles (Flatpak com.usebottles.bottles) pour créer des
environnements Windows isolés (« bouteilles »), et sur Wine Debian pour le
mode direct (terminal / binfmt_misc).

Licence : GPL-3.0-or-later.
"""

import datetime
import json
import os
import re
import shlex
import shutil
import struct
import subprocess
import sys
import time
import unicodedata

APP_ID = "com.usebottles.bottles"
VERSION = "1.1.0"

HOME = os.path.expanduser("~")
BOTTLES_DATA = os.environ.get(
    "AUBE_BOTTLES_DATA",
    os.path.join(HOME, ".var/app", APP_ID, "data/bottles"),
)
BOTTLES_DIR = os.path.join(BOTTLES_DATA, "bottles")
RUNNERS_DIR = os.path.join(BOTTLES_DATA, "runners")
STATE_DIR = os.path.join(
    os.environ.get("XDG_STATE_HOME", os.path.join(HOME, ".local/state")), "aube")
LOG_FILE = os.path.join(STATE_DIR, "windows.log")
APPS_DIR = os.path.join(
    os.environ.get("XDG_DATA_HOME", os.path.join(HOME, ".local/share")),
    "applications")
DESKTOP_PREFIX = "aube-win-"

SUPPORTED_EXT = (".exe", ".msi", ".bat", ".lnk", ".com")

ANTICHEAT_MARKERS = {
    "easyanticheat": "Easy Anti-Cheat",
    "battleye": "BattlEye",
    "vanguard": "Riot Vanguard",
    "faceit": "FACEIT",
    "xigncode": "XIGNCODE3",
    "nprotect": "nProtect GameGuard",
    "gameguard": "nProtect GameGuard",
    "ricochet": "Ricochet",
}


# ---------------------------------------------------------------- journal
def log(msg):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (datetime.datetime.now().isoformat(
                timespec="seconds"), msg))
    except OSError:
        pass


# ---------------------------------------------------------------- interface
class UI:
    """Boîtes de dialogue via zenity ; repli texte si pas d'affichage."""

    def __init__(self, batch=False):
        self.zenity = shutil.which(os.environ.get("AUBE_ZENITY", "zenity"))
        self.graphic = (not batch) and bool(self.zenity) and bool(
            os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
        self.title = "Programmes Windows"

    def _z(self, args, inp=None):
        cmd = [self.zenity, "--title=" + self.title] + args
        p = subprocess.run(cmd, input=inp, capture_output=True, text=True)
        return p.returncode, p.stdout.strip()

    def info(self, text):
        log("INFO " + text.replace("\n", " | "))
        if self.graphic:
            self._z(["--info", "--width=420", "--text=" + text])
        else:
            print(text)

    def error(self, text):
        log("ERREUR " + text.replace("\n", " | "))
        if self.graphic:
            self._z(["--error", "--width=460", "--text=" + text])
        else:
            print("Erreur : " + re.sub(r"</?b>", "", text), file=sys.stderr)

    def warning_continue(self, text):
        log("AVERTISSEMENT " + text.replace("\n", " | "))
        if self.graphic:
            rc, _ = self._z(["--question", "--width=460", "--icon=dialog-warning",
                             "--ok-label=Continuer quand même",
                             "--cancel-label=Annuler", "--text=" + text])
            return rc == 0
        print("Avertissement : " + text, file=sys.stderr)
        return True

    def question(self, text, ok="Oui", cancel="Non"):
        if self.graphic:
            rc, _ = self._z(["--question", "--width=420", "--ok-label=" + ok,
                             "--cancel-label=" + cancel, "--text=" + text])
            return rc == 0
        return True

    def choose(self, text, options, column="Choix"):
        """options : liste de (clé, libellé). Retourne la clé ou None."""
        if not self.graphic:
            return options[0][0] if options else None
        args = ["--list", "--width=560", "--height=360", "--text=" + text,
                "--column=id", "--column=" + column, "--hide-column=1",
                "--print-column=1"]
        for key, label in options:
            args += [key, label]
        rc, out = self._z(args)
        if rc != 0 or not out:
            return None
        return out.split("|")[0]

    def checklist(self, text, items):
        """items : liste de (clé, libellé) ; tout est coché par défaut."""
        if not self.graphic:
            return [k for k, _ in items]
        args = ["--list", "--checklist", "--width=560", "--height=360",
                "--text=" + text, "--column=", "--column=id", "--column=Programme",
                "--hide-column=2", "--print-column=2", "--separator=\n"]
        for key, label in items:
            args += ["TRUE", key, label]
        rc, out = self._z(args)
        if rc != 0:
            return []
        return [l for l in out.splitlines() if l]

    def entry(self, text, default):
        if not self.graphic:
            return default
        rc, out = self._z(["--entry", "--width=420", "--text=" + text,
                           "--entry-text=" + default])
        return out if rc == 0 and out else None

    def progress(self, text):
        """Barre de progression « en attente » ; retourne un objet à fermer."""
        log("ÉTAPE " + text)
        if not self.graphic:
            print(text + "…")
            return None
        return subprocess.Popen(
            [self.zenity, "--title=" + self.title, "--progress", "--pulsate",
             "--auto-close", "--no-cancel", "--width=420", "--text=" + text],
            stdin=subprocess.PIPE, text=True)

    @staticmethod
    def done(p):
        if p is not None:
            try:
                p.stdin.write("100\n")
                p.stdin.close()
                p.wait(timeout=5)
            except Exception:  # noqa: BLE001
                p.kill()


# ---------------------------------------------------------------- analyse PE
def inspect_executable(path):
    """Analyse l'en-tête d'un .exe. Retourne un dict (type, arch, raison)."""
    res = {"kind": "inconnu", "arch": None, "subsystem": None}
    try:
        with open(path, "rb") as f:
            head = f.read(4096)
    except OSError as e:
        res["kind"] = "illisible"
        res["error"] = str(e)
        return res
    if head[:2] != b"MZ":
        res["kind"] = "pas-mz"
        return res
    if len(head) < 0x40:
        res["kind"] = "dos"
        return res
    pe_off = struct.unpack_from("<I", head, 0x3C)[0]
    if pe_off + 0x5E > len(head):
        try:
            with open(path, "rb") as f:
                f.seek(pe_off)
                pe = f.read(0x60)
        except OSError:
            pe = b""
    else:
        pe = head[pe_off:pe_off + 0x60]
    if pe[:4] != b"PE\0\0":
        if pe[:2] in (b"NE", b"LE", b"LX"):
            res["kind"] = "win16"
        else:
            res["kind"] = "dos"
        return res
    machine = struct.unpack_from("<H", pe, 4)[0]
    res["arch"] = {0x14C: "x86", 0x8664: "x64", 0xAA64: "arm64",
                   0x1C0: "arm", 0x1C4: "arm"}.get(machine, hex(machine))
    characteristics = struct.unpack_from("<H", pe, 22)[0]
    opt = 24
    magic = struct.unpack_from("<H", pe, opt)[0]
    if magic in (0x10B, 0x20B) and len(pe) >= opt + 70:
        res["subsystem"] = struct.unpack_from("<H", pe, opt + 68)[0]
    if res["subsystem"] == 1:
        res["kind"] = "pilote"
    elif characteristics & 0x2000:
        res["kind"] = "dll"
    else:
        res["kind"] = "pe"
    return res


def _user_dirs():
    """Dossier personnel et dossiers utilisateur XDG (chemins réels)."""
    dirs = {HOME, "/tmp"}
    for d in ("Desktop", "Downloads", "Documents", "Bureau", "Téléchargements"):
        dirs.add(os.path.join(HOME, d))
    cfg = os.path.join(os.environ.get("XDG_CONFIG_HOME",
                                      os.path.join(HOME, ".config")), "user-dirs.dirs")
    try:
        with open(cfg, encoding="utf-8") as f:
            for line in f:
                m = re.match(r'^XDG_\w+_DIR="(.*)"\s*$', line)
                if m:
                    dirs.add(m.group(1).replace("$HOME", HOME))
    except OSError:
        pass
    return {os.path.realpath(d) for d in dirs}


def detect_anticheat(path):
    """Cherche des traces de systèmes anti-triche à côté du programme."""
    found = set()
    base = os.path.dirname(os.path.abspath(path))
    # Installateur posé dans le dossier personnel ou un dossier « fourre-tout »
    # (Téléchargements, Bureau…) : ses voisins n'ont rien à voir avec lui, on
    # ne les parcourt pas (faux positifs et lenteur sur les gros dossiers).
    if os.path.realpath(base) in _user_dirs():
        return []
    try:
        for root, dirs, files in os.walk(base):
            depth = root[len(base):].count(os.sep)
            if depth > 2:
                dirs[:] = []
                continue
            for name in dirs + files:
                low = name.lower()
                for marker, label in ANTICHEAT_MARKERS.items():
                    if marker in low:
                        found.add(label)
            if len(files) > 3000:
                break
    except OSError:
        pass
    return sorted(found)


def preflight(ui, path):
    """Vérifications avant exécution. Retourne True pour continuer."""
    ext = os.path.splitext(path)[1].lower()
    if not os.path.isfile(path):
        ui.error("Le fichier « %s » est introuvable." % path)
        return False
    if ext in (".exe", ".com"):
        info = inspect_executable(path)
        log("ANALYSE %s : %s" % (path, json.dumps(info)))
        kind = info["kind"]
        if kind == "pilote":
            ui.error("« %s » est un <b>pilote Windows</b>.\n\n"
                     "Les pilotes Windows ne peuvent pas fonctionner sous Linux "
                     "(ni avec Wine, ni avec Bottles). Le matériel est géré par "
                     "les pilotes Linux : consultez « Pilotes supplémentaires » "
                     "dans le menu." % os.path.basename(path))
            return False
        if kind == "pas-mz":
            ui.error("« %s » n'est pas un programme Windows valide "
                     "(fichier corrompu ou mal nommé)." % os.path.basename(path))
            return False
        if kind in ("dos", "win16"):
            if not ui.warning_continue(
                    "« %s » est un ancien programme %s.\nIl peut fonctionner, "
                    "mais DOSBox est souvent plus adapté aux programmes DOS."
                    % (os.path.basename(path),
                       "DOS" if kind == "dos" else "Windows 16 bits")):
                return False
        if info.get("arch") in ("arm64", "arm"):
            ui.error("« %s » est compilé pour processeur ARM et ne peut pas "
                     "fonctionner sur ce PC x86-64." % os.path.basename(path))
            return False
    ac = detect_anticheat(path)
    if ac:
        if not ui.warning_continue(
                "Ce programme semble utiliser un système anti-triche : %s.\n\n"
                "Beaucoup de jeux en ligne protégés refusent de fonctionner sous "
                "Linux, sauf si l'éditeur l'a explicitement autorisé. Le jeu "
                "peut s'installer mais refuser de se lancer en ligne."
                % ", ".join(ac)):
            return False
    return True


# ---------------------------------------------------------------- Bottles
def bottles_cli_cmd():
    override = os.environ.get("AUBE_BOTTLES_CLI")
    if override:
        return shlex.split(override)
    return ["flatpak", "run", "--command=bottles-cli", APP_ID]


def bottles_installed():
    if os.environ.get("AUBE_BOTTLES_CLI"):
        return True
    if not shutil.which("flatpak"):
        return False
    return subprocess.run(["flatpak", "info", APP_ID], capture_output=True
                          ).returncode == 0


def run_logged(cmd, timeout=None):
    log("CMD " + " ".join(shlex.quote(c) for c in cmd))
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        log("CMD délai dépassé")
        return 124, ""
    except OSError as e:
        log("CMD impossible : %s" % e)
        return 127, str(e)
    out = (p.stdout or "") + (p.stderr or "")
    for line in out.splitlines()[-40:]:
        log("  | " + line)
    return p.returncode, out


def _bottle_index():
    """{nom affiché: dossier}. Bottles remplace les espaces par « - » dans le
    nom de dossier : on lit donc le champ Name de bottle.yml."""
    res = {}
    if not os.path.isdir(BOTTLES_DIR):
        return res
    for d in sorted(os.listdir(BOTTLES_DIR)):
        yml = os.path.join(BOTTLES_DIR, d, "bottle.yml")
        if not os.path.isfile(yml):
            continue
        name = d
        try:
            with open(yml, encoding="utf-8", errors="replace") as f:
                for line in f:
                    m = re.match(r"^Name:\s*(.+?)\s*$", line)
                    if m:
                        name = m.group(1).strip("'\"")
                        break
        except OSError:
            pass
        res[name] = os.path.join(BOTTLES_DIR, d)
    return res


def list_bottles():
    return sorted(_bottle_index())


def runners_available():
    if os.environ.get("AUBE_BOTTLES_CLI"):
        return True
    try:
        return any(os.path.isdir(os.path.join(RUNNERS_DIR, r))
                   for r in os.listdir(RUNNERS_DIR))
    except OSError:
        return False


def slugify(text):
    t = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    t = re.sub(r"[^A-Za-z0-9]+", "-", t).strip("-")
    return t[:40] or "programme"


def default_bottle_name(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    stem = re.sub(r"(?i)[-_ ]?(setup|install(er)?|x64|x86|win(32|64)?|"
                  r"amd64|v?\d+(\.\d+)+)\b", " ", stem)
    stem = re.sub(r"[-_.]+", " ", stem).strip()
    name = stem.title() if stem else "Programme"
    name = re.sub(r"[^\w ]", "", name).strip()[:30] or "Programme"
    existing = set(list_bottles())
    candidate, i = name, 2
    while candidate in existing:
        candidate = "%s %d" % (name, i)
        i += 1
    return candidate


def create_bottle(ui, name, environment):
    pr = ui.progress("Création de l'environnement Windows « %s »\n"
                     "(première fois : jusqu'à quelques minutes)" % name)
    rc, out = run_logged(bottles_cli_cmd() + [
        "new", "--bottle-name", name, "--environment", environment],
        timeout=1800)
    ui.done(pr)
    if rc != 0 or name not in list_bottles():
        hint = ""
        low = out.lower()
        if "runner" in low or "no such file" in low:
            hint = ("\n\nIl manque probablement une version de Wine dans Bottles. "
                    "Connectez-vous à Internet puis ouvrez « Bottles » une fois "
                    "pour terminer sa configuration.")
        elif "network" in low or "connection" in low:
            hint = "\n\nUne connexion Internet est nécessaire pour cette étape."
        ui.error("Impossible de créer l'environnement « %s »." % name + hint +
                 "\n\nJournal : %s" % LOG_FILE)
        return False
    return True


def bottle_path(name):
    return _bottle_index().get(name) or os.path.join(
        BOTTLES_DIR, name.replace(" ", "-"))


def wine_processes(name):
    """PID des processus Wine dont WINEPREFIX pointe vers la bouteille."""
    target = ("WINEPREFIX=" + bottle_path(name)).encode()
    # Dans le Flatpak, le chemin est vu sous /home/... identique (même HOME).
    pids = []
    for pid in os.listdir("/proc"):
        if not pid.isdigit() or int(pid) == os.getpid():
            continue
        try:
            with open("/proc/%s/environ" % pid, "rb") as f:
                env = f.read()
        except OSError:
            continue
        for var in env.split(b"\0"):
            if var.rstrip(b"/") == target.rstrip(b"/"):
                pids.append(int(pid))
                break
    return pids


def stop_bottle(name, grace=10):
    """Arrête tous les processus Wine de la bouteille (TERM puis KILL).
    « bottles-cli stop » restait bloqué plus de 10 min en VM : on ne s'y fie pas."""
    pids = wine_processes(name)
    for sig in (15, 9):
        for pid in pids:
            try:
                os.kill(pid, sig)
            except OSError:
                pass
        deadline = time.time() + grace
        while time.time() < deadline:
            pids = wine_processes(name)
            if not pids:
                break
            time.sleep(0.5)
        if not pids:
            break
    log("ARRÊT environnement %s : %s" % (name, "ok" if not pids else
                                          "processus restants %s" % pids))
    return not pids


def wait_bottle_idle(name, grace=8, timeout=6 * 3600):
    """Attend que plus aucun processus Wine de la bouteille ne tourne."""
    start = time.time()
    idle_since = None
    while time.time() - start < timeout:
        if wine_processes(name):
            idle_since = None
        else:
            idle_since = idle_since or time.time()
            if time.time() - idle_since >= grace:
                return
        time.sleep(2)


def start_menu_links(name):
    """Raccourcis .lnk du menu Démarrer de la bouteille."""
    drive_c = os.path.join(bottle_path(name), "drive_c")
    roots = [os.path.join(drive_c, "ProgramData/Microsoft/Windows/Start Menu")]
    users = os.path.join(drive_c, "users")
    if os.path.isdir(users):
        for u in os.listdir(users):
            roots.append(os.path.join(
                users, u, "AppData/Roaming/Microsoft/Windows/Start Menu"))
            roots.append(os.path.join(users, u, "Start Menu"))
            roots.append(os.path.join(users, u, "Desktop"))
    links = set()
    for r in roots:
        if not os.path.isdir(r):
            continue
        for root, _dirs, files in os.walk(r):
            for f in files:
                if f.lower().endswith(".lnk"):
                    links.add(os.path.join(root, f))
    return links


def is_uninstaller(path):
    low = os.path.basename(path).lower()
    return any(w in low for w in ("uninstall", "désinstall", "desinstall",
                                  "unins0", "remove", "supprimer"))


def lnk_target(path):
    """Extrait le chemin cible (LocalBasePath) d'un raccourci .lnk."""
    try:
        with open(path, "rb") as f:
            data = f.read(65536)
        if len(data) < 0x4C or struct.unpack_from("<I", data, 0)[0] != 0x4C:
            return None
        flags = struct.unpack_from("<I", data, 0x14)[0]
        pos = 0x4C
        if flags & 0x01:  # HasLinkTargetIDList
            pos += 2 + struct.unpack_from("<H", data, pos)[0]
        if flags & 0x02:  # HasLinkInfo
            li = pos
            hdr = struct.unpack_from("<I", data, li + 4)[0]
            base_off = struct.unpack_from("<I", data, li + 16)[0]
            if hdr >= 0x24:
                uoff = struct.unpack_from("<I", data, li + 28)[0]
                if uoff:
                    end = data.find(b"\0\0", li + uoff)
                    while end != -1 and (end - (li + uoff)) % 2:
                        end = data.find(b"\0\0", end + 1)
                    return data[li + uoff:end].decode("utf-16-le", "ignore")
            end = data.find(b"\0", li + base_off)
            return data[li + base_off:end].decode("cp1252", "ignore")
    except (OSError, struct.error):
        return None
    return None


def windows_to_unix(name, winpath):
    if not winpath or len(winpath) < 3 or winpath[1] != ":":
        return None
    if winpath[0].lower() != "c":
        return None
    rel = winpath[3:].replace("\\", "/")
    base = os.path.join(bottle_path(name), "drive_c")
    # Résolution insensible à la casse, comme Windows.
    cur = base
    for part in [p for p in rel.split("/") if p]:
        try:
            match = next((e for e in os.listdir(cur) if e.lower() == part.lower()),
                         None)
        except OSError:
            return None
        if match is None:
            return None
        cur = os.path.join(cur, match)
    return cur


def extract_icon(name, exe_unix, slug):
    if not exe_unix or not shutil.which("wrestool") or not shutil.which("icotool"):
        return "wine"
    icon_dir = os.path.join(STATE_DIR, "icons")
    os.makedirs(icon_dir, exist_ok=True)
    ico = os.path.join(icon_dir, slug + ".ico")
    png = os.path.join(icon_dir, slug + ".png")
    try:
        with open(ico, "wb") as f:
            subprocess.run(["wrestool", "-x", "-t", "14", exe_unix], stdout=f,
                           stderr=subprocess.DEVNULL, timeout=30)
        if os.path.getsize(ico) == 0:
            return "wine"
        lst = subprocess.run(["icotool", "-l", ico], capture_output=True,
                             text=True, timeout=30).stdout
        best, best_size = None, 0
        for line in lst.splitlines():
            m = re.search(r"--index=(\d+) --width=(\d+)", line)
            if m and int(m.group(2)) >= best_size and int(m.group(2)) <= 256:
                best, best_size = m.group(1), int(m.group(2))
        args = ["icotool", "-x", "-o", png, ico]
        if best:
            args.insert(2, "--index=" + best)
        subprocess.run(args, capture_output=True, timeout=30)
        return png if os.path.isfile(png) else "wine"
    except (OSError, subprocess.SubprocessError):
        return "wine"


def desktop_escape(s):
    """Échappement d'une valeur de type chaîne (fichier .desktop)."""
    return (s.replace("\\", "\\\\").replace("\n", " ").replace("\r", " ")
            .replace("\t", " "))


def desktop_unescape(s):
    return re.sub(r"\\(.)", lambda m: {"s": " ", "n": "\n", "t": "\t",
                                        "r": "\r"}.get(m.group(1), m.group(1)), s)


def exec_quote(s):
    """Argument de la clé Exec conforme à la spécification Desktop Entry :
    guillemets (avec \\ devant " ` $ et \\), %% pour %, puis échappement de
    niveau « chaîne » (chaque \\ doublé), sans quoi GLib/garcon rejettent
    la clé (« invalid escape sequence »)."""
    out = '"'
    for ch in s:
        if ch in '"`$\\':
            out += "\\"
        out += ch
    out += '"'
    return out.replace("%", "%%").replace("\\", "\\\\")


def add_menu_entry(name, lnk):
    title = os.path.splitext(os.path.basename(lnk))[0]
    slug = slugify(name) + "-" + slugify(title)
    target = windows_to_unix(name, lnk_target(lnk))
    icon = extract_icon(name, target, slug)
    os.makedirs(APPS_DIR, exist_ok=True)
    path = os.path.join(APPS_DIR, DESKTOP_PREFIX + slug + ".desktop")
    with open(path, "w", encoding="utf-8") as f:
        f.write("[Desktop Entry]\nType=Application\n")
        f.write("Name=%s\n" % desktop_escape(title))
        f.write("Comment=Programme Windows (environnement « %s »)\n"
                % desktop_escape(name))
        f.write("Exec=aube-windows --launch %s %s\n"
                % (exec_quote(name), exec_quote(lnk)))
        # « X-Wine » : catégorie non standard préfixée (desktop-file-validate)
        f.write("Icon=%s\nCategories=Utility;X-Wine;\nTerminal=false\n" % icon)
        f.write("StartupNotify=true\nX-Aube-Bottle=%s\n" % desktop_escape(name))
        f.write("X-Aube-Lnk=%s\n" % desktop_escape(lnk))
        f.write("Actions=arreter;desinstaller;reglages;\n\n")
        f.write("[Desktop Action arreter]\nName=Forcer l'arrêt\n")
        f.write("Exec=aube-windows --stop %s\n\n" % exec_quote(name))
        f.write("[Desktop Action desinstaller]\nName=Désinstaller\n")
        f.write("Exec=aube-windows --uninstall %s\n\n" % exec_quote(name))
        f.write("[Desktop Action reglages]\nName=Réglages de l'environnement\n")
        f.write("Exec=flatpak run %s\n" % APP_ID)
    os.chmod(path, 0o755)
    log("MENU ajout %s" % path)
    return path


def menu_entries_for(name):
    res = []
    if not os.path.isdir(APPS_DIR):
        return res
    for f in os.listdir(APPS_DIR):
        if not f.startswith(DESKTOP_PREFIX):
            continue
        p = os.path.join(APPS_DIR, f)
        try:
            with open(p, encoding="utf-8") as fh:
                if ("X-Aube-Bottle=%s\n" % desktop_escape(name)) in fh.read():
                    res.append(p)
        except OSError:
            pass
    return res


def refresh_menu():
    if shutil.which("update-desktop-database"):
        subprocess.run(["update-desktop-database", APPS_DIR],
                       capture_output=True)


def unix_to_windows(name, path):
    """Chemin Unix dans drive_c de la bouteille -> « C:\\… » ; sinon None."""
    drive_c = os.path.realpath(os.path.join(bottle_path(name), "drive_c"))
    real = os.path.realpath(path)
    if real != drive_c and not real.startswith(drive_c + os.sep):
        return None
    return "C:\\" + os.path.relpath(real, drive_c).replace("/", "\\")


# Dossiers Windows de l'utilisateur → vrais dossiers Linux (XDG). Le Bureau
# n'est pas relié : les installateurs y déposent des raccourcis Windows.
DOSSIERS_LIES = (("Downloads", "DOWNLOAD"), ("Documents", "DOCUMENTS"),
                 ("Pictures", "PICTURES"), ("Music", "MUSIC"), ("Videos", "VIDEOS"))


def xdg_dir(cle):
    try:
        r = subprocess.run(["xdg-user-dir", cle], capture_output=True, text=True, timeout=10)
        d = r.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        d = ""
    return d if d and os.path.isdir(d) and d != os.path.expanduser("~") else None


def deplacer_sans_ecraser(src, dst_dir):
    """Déplace src dans dst_dir ; en cas de nom déjà pris : « nom (2) »."""
    base = os.path.basename(src)
    cible = os.path.join(dst_dir, base)
    n = 2
    while os.path.lexists(cible):
        racine, ext = os.path.splitext(base)
        cible = os.path.join(dst_dir, "%s (%d)%s" % (racine, n, ext))
        n += 1
    shutil.move(src, cible)


def vide(d):
    """Vrai si l'arborescence d ne contient aucun fichier (que des dossiers)."""
    for _r, _ds, fs in os.walk(d):
        if fs:
            return False
    return True


def relier_dossiers(name):
    """Téléchargements, Documents, Images, Musique, Vidéos partagés avec
    Linux, et lecteur D: = /media/<utilisateur> (disques internes). Ce qui se
    trouvait déjà dans un dossier Windows est déplacé dans le dossier Linux.
    Sans danger à relancer."""
    users = os.path.join(bottle_path(name), "drive_c", "users")
    if not os.path.isdir(users):
        return
    for u in os.listdir(users):
        if u in ("Public", "steamuser") or not os.path.isdir(os.path.join(users, u)):
            continue
        for win, cle in DOSSIERS_LIES:
            lin = xdg_dir(cle)
            w = os.path.join(users, u, win)
            if not lin or (os.path.islink(w) and os.path.realpath(w) == os.path.realpath(lin)):
                continue
            try:
                if os.path.isdir(w) and not os.path.islink(w):
                    for e in os.listdir(w):
                        src = os.path.join(w, e)
                        # Dossiers vides créés par Wine/Bottles (Documents\Music…) :
                        # supprimés plutôt que déplacés (sinon « Music (2) »…).
                        if os.path.isdir(src) and not os.path.islink(src) and vide(src):
                            shutil.rmtree(src)
                            continue
                        deplacer_sans_ecraser(src, lin)
                    os.rmdir(w)
                elif os.path.lexists(w):
                    os.remove(w)
                os.symlink(lin, w)
                log("DOSSIER %s : %s -> %s" % (name, w, lin))
            except OSError as e:
                log("DOSSIER %s : %s non relié (%s)" % (name, w, e))
    media = os.path.join("/media", os.environ.get("USER", ""))
    d = os.path.join(bottle_path(name), "dosdevices", "d:")
    if os.path.isdir(media) and not os.path.lexists(d):
        try:
            os.symlink(media, d)
            log("LECTEUR %s : D: -> %s" % (name, media))
        except OSError:
            pass


def run_in_bottle(ui, name, path, wait=True, args=()):
    relier_dossiers(name)
    if path.lower().endswith(".lnk"):
        # bottles-cli refuse un .lnk donné en chemin Unix (« exec_type lnk is
        # not valid », constaté en VM) ; en chemin Windows, il passe par
        # start.exe, qui respecte la cible, les arguments et le dossier.
        path = unix_to_windows(name, path) or path
    cmd = bottles_cli_cmd() + ["run", "-b", name, "-e", path]
    if args:  # « -- » : bottles-cli (argparse) ne doit pas interpréter « -x »
        cmd += ["--"] + list(args)
    log("CMD " + " ".join(shlex.quote(c) for c in cmd))
    t0 = time.time()
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(LOG_FILE, "a") as logf:
            rc = subprocess.call(cmd, stdout=logf, stderr=subprocess.STDOUT)
    except OSError as e:
        ui.error("Impossible de démarrer Bottles : %s" % e)
        return 127
    if wait:
        wait_bottle_idle(name)
    log("FIN rc=%s durée=%.0fs" % (rc, time.time() - t0))
    return rc


# ---------------------------------------------------------------- actions
def require_bottles(ui):
    if not bottles_installed():
        ui.error("Bottles n'est pas installé sur ce système.\n\n"
                 "Réinstallez-le avec « Mises à jour » ou, dans un terminal :\n"
                 "sudo flatpak install flathub %s" % APP_ID)
        return False
    if not runners_available():
        if ui.question("Bottles doit d'abord télécharger ses composants "
                       "(Wine, DXVK…). Une connexion Internet est nécessaire.\n\n"
                       "Ouvrir Bottles pour terminer la configuration ?",
                       ok="Ouvrir Bottles", cancel="Annuler"):
            subprocess.Popen(["flatpak", "run", APP_ID])
        return False
    return True


def open_file(ui, path, args=()):
    path = os.path.abspath(path)
    log("OUVERTURE %s" % path)
    if not preflight(ui, path):
        return 1
    if not require_bottles(ui):
        return 1
    base = os.path.basename(path)
    options = [("__new_app", "Nouvel environnement isolé — application (recommandé)"),
               ("__new_game", "Nouvel environnement isolé — jeu (DXVK, VKD3D-Proton)")]
    for b in list_bottles():
        options.append(("b:" + b, "Environnement existant : %s" % b))
    choice = ui.choose("Que faire avec « %s » ?" % base, options, column="Action")
    if not choice:
        return 1
    if choice.startswith("__new"):
        env = "gaming" if choice == "__new_game" else "application"
        name = ui.entry("Nom du nouvel environnement :",
                        default_bottle_name(path))
        if not name:
            return 1
        name = re.sub(r"[^\w .-]", "", name).strip()[:40] or "Programme"
        if name in list_bottles():
            ui.error("Un environnement « %s » existe déjà." % name)
            return 1
        if not create_bottle(ui, name, env):
            return 1
    else:
        name = choice[2:]
    before = start_menu_links(name)
    rc = run_in_bottle(ui, name, path, args=args)
    after = start_menu_links(name)
    new = sorted(l for l in after - before if not is_uninstaller(l))
    if not new:
        # Réinstallation, ou question du premier passage fermée sans réponse
        # (l'installateur lance souvent le programme à la fin) : on propose
        # les programmes de l'environnement qui ne sont pas encore au menu.
        deja = set()
        for e in menu_entries_for(name):
            try:
                with open(e, encoding="utf-8") as fh:
                    for ligne in fh:
                        if ligne.startswith("X-Aube-Lnk="):
                            deja.add(desktop_unescape(ligne[len("X-Aube-Lnk="):].rstrip("\n")))
            except OSError:
                pass
        cibles = {(lnk_target(l) or "").lower() for l in deja}
        new = []
        for l in sorted(after):
            c = (lnk_target(l) or "").lower()
            if is_uninstaller(l) or l in deja or not c.endswith(".exe") or c in cibles:
                continue
            cibles.add(c)  # un seul raccourci par programme (menu, Bureau…)
            new.append(l)
    if new:
        items = [(l, os.path.splitext(os.path.basename(l))[0]) for l in new]
        chosen = ui.checklist("Installation terminée. Ajouter ces programmes au "
                              "menu des applications ?", items)
        for l in chosen:
            add_menu_entry(name, l)
            # Bibliothèque de Bottles : il lui faut l'exécutable, pas le .lnk.
            target = windows_to_unix(name, lnk_target(l))
            if target:
                run_logged(bottles_cli_cmd() + [
                    "add", "-b", name, "-n",
                    os.path.splitext(os.path.basename(l))[0], "-p", target],
                    timeout=300)
        refresh_menu()
        if chosen:
            ui.info("Les programmes sont dans le menu, rubrique "
                    "« Programmes Windows ».")
    elif rc != 0:
        ui.error("Le programme s'est arrêté avec une erreur (code %s).\n\n"
                 "Journal : %s\nOutil d'aide : « Diagnostic Windows » dans le menu."
                 % (rc, LOG_FILE))
        return rc
    return 0


def launch(ui, name, lnk):
    if name not in list_bottles():
        ui.error("L'environnement Windows « %s » n'existe plus." % name)
        return 1
    if not require_bottles(ui):
        return 1
    rc = run_in_bottle(ui, name, lnk, wait=False)
    if rc != 0:
        ui.error("Le programme n'a pas pu démarrer (code %s).\n\nJournal : %s"
                 % (rc, LOG_FILE))
    return rc


def uninstall(ui, name):
    if name not in list_bottles():
        ui.error("L'environnement « %s » n'existe pas." % name)
        return 1
    choice = ui.choose(
        "Désinstallation — environnement « %s »" % name,
        [("prog", "Désinstaller un programme de cet environnement"),
         ("all", "Supprimer tout l'environnement et ses programmes")],
        column="Action")
    if choice == "prog":
        run_logged(bottles_cli_cmd() + ["tools", "uninstaller", "-b", name])
        wait_bottle_idle(name, grace=4)
        cleanup_menu(name)
        return 0
    if choice == "all":
        return delete_bottle(ui, name)
    return 1


def cleanup_menu(name):
    """Retire les entrées de menu dont le raccourci a disparu."""
    for p in menu_entries_for(name):
        with open(p, encoding="utf-8") as f:
            m = re.search(r"^X-Aube-Lnk=(.*)$", f.read(), re.M)
        if m:
            lnk = desktop_unescape(m.group(1))
            if not os.path.exists(lnk):
                os.remove(p)
                log("MENU retrait %s" % p)
    refresh_menu()


def delete_bottle(ui, name, confirm=True):
    if confirm and not ui.question(
            "Supprimer définitivement l'environnement « %s » ?\n\nTous les "
            "programmes et fichiers qu'il contient seront effacés." % name,
            ok="Supprimer", cancel="Annuler"):
        return 1
    stop_bottle(name)
    path = bottle_path(name)
    if os.path.dirname(os.path.abspath(path)) == os.path.abspath(BOTTLES_DIR):
        shutil.rmtree(path, ignore_errors=True)
    for p in menu_entries_for(name):
        os.remove(p)
    refresh_menu()
    log("SUPPRESSION environnement %s" % name)
    if name in list_bottles():
        ui.error("La suppression de « %s » a échoué." % name)
        return 1
    ui.info("Environnement « %s » supprimé." % name)
    return 0


def manager(ui):
    if not require_bottles(ui):
        return 1
    bottles = list_bottles()
    options = [("__open", "Ouvrir Bottles (réglages avancés, versions de Wine, "
                          "DXVK, dépendances)"),
               ("__file", "Installer un programme Windows (.exe / .msi)…"),
               ("__diag", "Diagnostic et journaux")]
    for b in bottles:
        n = len(menu_entries_for(b))
        options.append(("b:" + b, "Gérer « %s » (%d raccourci%s)"
                        % (b, n, "s" if n > 1 else "")))
    choice = ui.choose("Programmes Windows — que voulez-vous faire ?", options,
                       column="Action")
    if not choice:
        return 0
    if choice == "__open":
        os.execvp("flatpak", ["flatpak", "run", APP_ID])
    if choice == "__diag":
        os.execvp("aube-diagnostic-windows", ["aube-diagnostic-windows"])
    if choice == "__file":
        if not ui.graphic:
            return 1
        rc, out = ui._z(["--file-selection", "--file-filter=Programmes Windows | "
                         "*.exe *.EXE *.msi *.MSI *.bat *.lnk"])
        return open_file(ui, out) if rc == 0 and out else 0
    return uninstall(ui, choice[2:])


def direct(args):
    """Mode direct (terminal, binfmt_misc) : Wine Debian, préfixe ~/.wine."""
    wine = shutil.which("wine")
    if not wine:
        print("aube-windows : Wine n'est pas installé (sudo apt install wine).",
              file=sys.stderr)
        return 127
    log("DIRECT " + " ".join(args))
    os.execv(wine, [wine] + args)
    return 0  # non atteint


USAGE = """Utilisation : aube-windows [FICHIER.exe|.msi]
  (sans argument)           gestionnaire des programmes Windows
  FICHIER                   installer / lancer dans un environnement isolé
  --launch BOUTEILLE CHEMIN lancer un programme installé
  --uninstall BOUTEILLE     désinstaller
  --stop BOUTEILLE          arrêter tous les programmes d'un environnement
  --delete BOUTEILLE        supprimer un environnement (sans confirmation)
  --direct FICHIER [ARGS]   exécuter avec Wine Debian (mode terminal)
  --list                    lister les environnements
  --check FICHIER           analyser un exécutable
  --batch FICHIER [-- ARGS] installation sans dialogue (nouvel environnement
                            « application », raccourcis ajoutés), ex. /S
  --version
"""


def main(argv):
    if argv[:1] == ["--direct"]:
        return direct(argv[1:])
    ui = UI()
    if not argv:
        return manager(ui)
    a = argv[0]
    if a in ("-h", "--help"):
        print(USAGE)
        return 0
    if a == "--version":
        print("aube-windows", VERSION)
        return 0
    if a == "--list":
        for b in list_bottles():
            print(b)
        return 0
    if a == "--check" and len(argv) == 2:
        info = inspect_executable(argv[1])
        info["anticheat"] = detect_anticheat(argv[1])
        print(json.dumps(info, ensure_ascii=False))
        return 0
    if a == "--launch" and len(argv) == 3:
        return launch(ui, argv[1], argv[2])
    if a == "--uninstall" and len(argv) == 2:
        return uninstall(ui, argv[1])
    if a == "--batch" and len(argv) >= 2:
        rest = argv[2:]
        if rest[:1] == ["--"]:
            rest = rest[1:]
        return open_file(UI(batch=True), argv[1], args=rest)
    if a == "--stop" and len(argv) == 2:
        return 0 if stop_bottle(argv[1]) else 1
    if a == "--delete" and len(argv) == 2:
        # Commande de terminal/script : aucune fenêtre (le message de fin
        # zenity bloquait la commande, constaté en VM).
        return delete_bottle(UI(batch=True), argv[1], confirm=False)
    if a.startswith("file://"):
        from urllib.parse import unquote, urlparse
        a = unquote(urlparse(a).path)
    if not a.startswith("-"):
        return open_file(ui, a)
    print(USAGE, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
