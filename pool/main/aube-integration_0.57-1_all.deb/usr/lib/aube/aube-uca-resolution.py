"""Ajoute « Résolution (images et vidéos) » au clic droit de Thunar (uca.xml,
créé depuis /etc/xdg/Thunar/uca.xml s'il n'existe pas). Relançable."""
import os, shutil, sys
import xml.etree.ElementTree as ET

f = sys.argv[1]
if not os.path.exists(f):
    os.makedirs(os.path.dirname(f), exist_ok=True)
    shutil.copy('/etc/xdg/Thunar/uca.xml', f)
arbre = ET.parse(f)
racine = arbre.getroot()
if 'aube-resolution' not in {a.findtext('unique-id') for a in racine.findall('action')}:
    a = ET.SubElement(racine, 'action')
    for cle, val in (('icon', 'image-x-generic'), ('name', 'Résolution (images et vidéos)'),
                     ('submenu', ''), ('unique-id', 'aube-resolution'),
                     ('command', 'aube-resolution %F'),
                     ('description', 'Largeur × hauteur en pixels, définition et durée'),
                     ('range', ''), ('patterns', '*')):
        ET.SubElement(a, cle).text = val
    for cond in ('directories', 'image-files', 'video-files'):
        ET.SubElement(a, cond)
arbre.write(f, encoding='UTF-8', xml_declaration=True)
