"""Aube Linux : téléchargement du modèle de recherche de photos (CLIP).

≈ 320 Mo, une seule fois, depuis Hugging Face, révisions fixées et empreintes
SHA-256 vérifiées. Ensuite, la recherche fonctionne sans Internet.
  - côté image : Xenova/clip-vit-base-patch32 (ONNX fp16, licence MIT d'OpenAI CLIP)
  - côté texte : sentence-transformers/clip-ViT-B-32-multilingual-v1
    (OpenVINO int8, Apache 2.0), 50 langues dont le français
"""
import hashlib, os, urllib.request

DOSSIER = os.path.expanduser('~/.cache/aube/recherche')
TAILLE = '320 Mo'
_M = 'https://huggingface.co/sentence-transformers/clip-ViT-B-32-multilingual-v1/resolve/' \
     '58edf8cada9e398793dca955574a48cbb7f18be2/'
_X = 'https://huggingface.co/Xenova/clip-vit-base-patch32/resolve/d15189d7028b43f1d3e65039190477f6af591c2a/'
FICHIERS = [
    ('texte/openvino_model_qint8_quantized.xml', _M + 'openvino/openvino_model_qint8_quantized.xml',
     '50fdaf32d85e68e953c29d3d6ccb64235083504c2b16be28b1286b18a9f15dca'),
    ('texte/openvino_model_qint8_quantized.bin', _M + 'openvino/openvino_model_qint8_quantized.bin',
     '14a716d633306dfda26e639bc9a040142675c94707096151622f1660cc554995'),
    ('texte/vocab.txt', _M + 'vocab.txt', 'fe0fda7c425b48c516fc8f160d594c8022a0808447475c1a7c6d6479763f310c'),
    ('texte/2_Dense/model.safetensors', _M + '2_Dense/model.safetensors',
     'd12568dc7300970a4d3dbb49068ad16cd89b99840b74b026f8e48071e9414f74'),
    ('image/vision_model_fp16.onnx', _X + 'onnx/vision_model_fp16.onnx',
     '35c4e0fb0aeee527dcde1693520b214a34424a786babd530f35366bad5844efd'),
]


def sha256(f):
    h = hashlib.sha256()
    with open(f, 'rb') as fh:
        for bloc in iter(lambda: fh.read(1 << 20), b''):
            h.update(bloc)
    return h.hexdigest()


def present():
    return os.path.isfile(os.path.join(DOSSIER, '.verifie'))


def telecharger(progres=lambda i, n, nom, recu, total: None):
    for i, (rel, url, empreinte) in enumerate(FICHIERS):
        dst = os.path.join(DOSSIER, rel)
        if os.path.exists(dst) and sha256(dst) == empreinte:
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with urllib.request.urlopen(url, timeout=60) as r, open(dst + '.partiel', 'wb') as fh:
            total = int(r.headers.get('Content-Length') or 0)
            recu = 0
            while True:
                bloc = r.read(1 << 20)
                if not bloc:
                    break
                fh.write(bloc)
                recu += len(bloc)
                progres(i, len(FICHIERS), os.path.basename(rel), recu, total)
        if sha256(dst + '.partiel') != empreinte:
            os.remove(dst + '.partiel')
            raise RuntimeError('empreinte incorrecte pour %s (téléchargement altéré)' % rel)
        os.rename(dst + '.partiel', dst)
    open(os.path.join(DOSSIER, '.verifie'), 'w').close()
