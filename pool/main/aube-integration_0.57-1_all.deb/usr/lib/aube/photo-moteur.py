"""Moteur de l'éditeur Photo d'Aube : retouches et IA (OpenVINO, NPU Intel).

Lancé par aube-photo avec le Python d'OpenVINO (/opt/aube/openvino) :
    python3 -I photo-moteur.py MODELES CACHE
Lignes JSON en entrée, une réponse JSON par requête ({"ok": ...} ou
{"erreur": ...}) ; les images passent par des fichiers PNG.
  {"op": "ajuster", "src", "dst", "reglages": {...}}
  {"op": "auto", "src"}                      → réglages proposés
  {"op": "fond", "src", "dst"}               → PNG transparent (IS-Net)
  {"op": "gomme", "src", "masque", "dst"}    → objet effacé (LaMa)
  {"op": "agrandir", "src", "dst"}           → ×4 (Real-ESRGAN general x4v3)
  {"op": "creer", "texte", "dst", "graine"}  → image 512×512 (LCM Dreamshaper)
Chaque modèle est chargé au premier usage, sur le NPU si possible, sinon sur
le processeur ; la compilation est gardée dans CACHE.
"""
import json, os, pickle, sys, time, zipfile

import numpy as np
from PIL import Image, ImageFilter

# Seul : chemins en arguments. Importé par le moteur commun aube-ia : chemins
# par défaut (~/.cache/aube/photo).
if __name__ == '__main__':
    MODELES, CACHE = sys.argv[1], sys.argv[2]
else:
    MODELES = os.path.expanduser('~/.cache/aube/photo')
    CACHE = os.path.join(MODELES, 'cache')
_core = None
_compiles = {}


def dire(**kw):
    print(json.dumps(kw, ensure_ascii=False), flush=True)


def core():
    global _core
    if _core is None:
        import openvino as ov
        _core = ov.Core()
        _core.set_property({'CACHE_DIR': CACHE})
    return _core


def compiler(cle, modele, forme=None):
    """Compile un modèle (objet ou chemin), NPU d'abord, processeur sinon."""
    if cle in _compiles:
        return _compiles[cle]
    c = core()
    m = c.read_model(modele) if isinstance(modele, str) else modele
    if isinstance(forme, dict):     # une forme par entrée (nom → forme)
        m.reshape({i: forme[n] for i in m.inputs for n in i.get_names() if n in forme})
    elif forme:
        m.reshape(forme)
    # Le NPU exige des dimensions fixes : sinon, directement le processeur
    # (une tentative sur le NPU peut faire planter le processus).
    statique = all(i.get_partial_shape().is_static for i in m.inputs)
    for dev in (['NPU'] if statique and 'NPU' in c.available_devices else []) + ['CPU']:
        try:
            t0 = time.perf_counter()
            cm = c.compile_model(m, dev)
            _compiles[cle] = (cm, dev)
            dire(info='%s prêt sur %s en %.1f s' % (cle, dev, time.perf_counter() - t0))
            return _compiles[cle]
        except Exception as e:
            dire(info='%s : %s indisponible (%s)' % (cle, dev, str(e)[:150]))
    raise RuntimeError('modèle %s impossible à charger' % cle)


def lire(chemin):
    im = Image.open(chemin)
    im.load()
    return im


def rgb_alpha(im):
    """Image → (RGB float32 0..1 [H,W,3], alpha uint8 ou None)."""
    alpha = im.getchannel('A') if im.mode in ('RGBA', 'LA') else None
    rgb = np.asarray(im.convert('RGB'), dtype=np.float32) / 255
    return rgb, alpha


def ecrire(rgb, alpha, dst):
    im = Image.fromarray((np.clip(rgb, 0, 1) * 255 + 0.5).astype(np.uint8), 'RGB')
    if alpha is not None:
        im.putalpha(alpha.resize(im.size) if alpha.size != im.size else alpha)
    im.save(dst)


# ------------------------------------------------------------- réglages ---
def luminance(rgb):
    return rgb @ np.array([0.2126, 0.7152, 0.0722], np.float32)


def ajuster(rgb, r):
    """Réglages façon Photos de Windows (valeurs de -100 à 100)."""
    g = lambda k: float(r.get(k, 0)) / 100
    x = rgb.copy()
    if g('exposition'):
        x *= 2 ** (g('exposition') * 1.5)
    if g('luminosite'):
        b = g('luminosite')
        x = 1 - (1 - x) ** (1 + b) if b > 0 else x ** (1 - b)
    if g('contraste'):
        c = 1 + g('contraste') * (0.8 if g('contraste') > 0 else 0.6)
        x = (x - 0.5) * c + 0.5
    if g('ombres') or g('hautes'):
        y = np.clip(luminance(x), 0, 1)[..., None]
        o = g('ombres') * 0.45 * (1 - y) ** 2      # zones sombres
        h = g('hautes') * 0.45 * y ** 2            # zones claires
        x = np.where(o > 0, x + o * (1 - x), x * (1 + o))
        x = np.where(h > 0, x + h * (1 - x), x * (1 + h))
    if g('temperature'):
        t = g('temperature') * 0.12
        x = x * np.array([1 + t, 1 + t * 0.15, 1 - t], np.float32)
    if g('teinte'):
        t = g('teinte') * 0.08
        x = x * np.array([1 + t * 0.5, 1 - t, 1 + t * 0.5], np.float32)
    if g('saturation') or g('vibrance'):
        y = luminance(x)[..., None]
        s = 1 + g('saturation')
        if g('vibrance'):
            sat = x.max(-1, keepdims=True) - x.min(-1, keepdims=True)
            s = s + g('vibrance') * (1 - np.clip(sat * 2, 0, 1))
        x = y + (x - y) * s
    if g('vignette'):
        h, w = x.shape[:2]
        yy, xx = np.ogrid[:h, :w]
        d = ((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2
        x = x * (1 - g('vignette') * 0.5 * np.clip(d - 0.3, 0, 1))[..., None]
    x = np.clip(x, 0, 1)
    if g('nettete') > 0:
        im = Image.fromarray((x * 255 + 0.5).astype(np.uint8))
        im = im.filter(ImageFilter.UnsharpMask(radius=2, percent=int(g('nettete') * 150), threshold=2))
        x = np.asarray(im, dtype=np.float32) / 255
    elif g('nettete') < 0:
        im = Image.fromarray((x * 255 + 0.5).astype(np.uint8))
        x = np.asarray(im.filter(ImageFilter.GaussianBlur(-g('nettete') * 4)), dtype=np.float32) / 255
    return x


def auto(rgb):
    """Amélioration automatique : niveaux, exposition et couleur estimés."""
    y = luminance(rgb)
    bas, haut = np.percentile(y, 1), np.percentile(y, 99)
    moy = float(y.mean())
    m = rgb.reshape(-1, 3).mean(0)
    r = {
        'exposition': round(float(np.clip((0.46 - moy) * 120, -40, 40))),
        'contraste': round(float(np.clip((0.75 - (haut - bas)) * 80, -10, 35))),
        'ombres': round(float(np.clip((0.12 - bas) * 200, 0, 30))),
        'temperature': round(float(np.clip((m[2] - m[0]) * 150, -25, 25))),
        'vibrance': 15,
    }
    return r


# ------------------------------------------------------------ arrière-plan ---
def fond(im):
    cm, _ = compiler('arriere-plan', os.path.join(MODELES, 'isnet', 'isnet-general-use.onnx'),
                     [1, 3, 1024, 1024])
    rgb, _a = rgb_alpha(im)
    x = np.asarray(Image.fromarray((rgb * 255).astype(np.uint8)).resize((1024, 1024), Image.BILINEAR),
                   dtype=np.float32) / 255
    x = ((x - 0.5) / 1.0).transpose(2, 0, 1)[None]
    m = cm(x)[0][0, 0]
    m = (m - m.min()) / (m.max() - m.min() + 1e-8)
    masque = Image.fromarray((m * 255).astype(np.uint8)).resize(im.size, Image.BILINEAR)
    return rgb, masque


# ---------------------------------------------------------------- gomme ---
def gomme(im, masque_im):
    cm, _ = compiler('gomme', os.path.join(MODELES, 'lama', 'lama_fp32.onnx'),
                     {'image': [1, 3, 512, 512], 'mask': [1, 1, 512, 512]})
    rgb, alpha = rgb_alpha(im)
    msk = np.asarray(masque_im.convert('L').resize(im.size), dtype=np.uint8) > 127
    if not msk.any():
        raise RuntimeError('rien à effacer : coloriez d\'abord la zone')
    H, W = msk.shape
    ys, xs = np.nonzero(msk)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    # Zone de travail carrée autour de l'objet, avec du contexte autour.
    cote = int(max(y1 - y0, x1 - x0) * 2.2) + 32
    cote = min(max(cote, 256), max(H, W))
    cy, cx = (y0 + y1) // 2, (x0 + x1) // 2
    ya = int(np.clip(cy - cote // 2, 0, max(H - cote, 0)))
    xa = int(np.clip(cx - cote // 2, 0, max(W - cote, 0)))
    yb, xb = min(ya + cote, H), min(xa + cote, W)
    zone = rgb[ya:yb, xa:xb]
    zm = msk[ya:yb, xa:xb]
    # Masque légèrement élargi : les bords de l'objet partent aussi.
    zm_img = Image.fromarray((zm * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(9))
    z512 = np.asarray(Image.fromarray((zone * 255).astype(np.uint8)).resize((512, 512), Image.BICUBIC),
                      dtype=np.float32) / 255
    m512 = (np.asarray(zm_img.resize((512, 512), Image.NEAREST), dtype=np.float32) > 127).astype(np.float32)
    entrees = {}
    for inp in cm.inputs:
        n = inp.get_any_name()
        entrees[n] = m512[None, None] if 'mask' in n.lower() else z512.transpose(2, 0, 1)[None]
    out = cm(entrees)[0][0].transpose(1, 2, 0)
    if out.max() > 2:
        out = out / 255
    out = np.asarray(Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8)).resize(
        (xb - xa, yb - ya), Image.BICUBIC), dtype=np.float32) / 255
    doux = np.asarray(zm_img.filter(ImageFilter.GaussianBlur(3)), dtype=np.float32)[..., None] / 255
    rgb[ya:yb, xa:xb] = zone * (1 - doux) + out * doux
    return rgb, alpha


# ------------------------------------------------------------- agrandir ---
class _Stockage:
    def __init__(self, cle, dtype):
        self.cle, self.dtype = cle, dtype


class _Lecteur(pickle.Unpickler):
    """Lit un state_dict PyTorch (format zip) sans PyTorch et sans exécuter de
    code : seules quelques reconstructions de tenseurs sont autorisées."""
    TYPES = {'FloatStorage': np.float32, 'HalfStorage': np.float16, 'DoubleStorage': np.float64}

    def __init__(self, fh, archive, prefixe):
        super().__init__(fh)
        self.archive, self.prefixe = archive, prefixe

    def find_class(self, module, nom):
        if module == 'collections' and nom == 'OrderedDict':
            import collections
            return collections.OrderedDict
        if module == 'torch._utils' and nom == '_rebuild_tensor_v2':
            return self._tenseur
        if module == 'torch' and nom in self.TYPES:
            return self.TYPES[nom]
        raise pickle.UnpicklingError('élément refusé : %s.%s' % (module, nom))

    def persistent_load(self, pid):
        _tag, dtype, cle, _lieu, _n = pid
        return _Stockage(cle, dtype)

    def _tenseur(self, st, decalage, taille, pas, *_):
        brut = np.frombuffer(self.archive.read('%s/data/%s' % (self.prefixe, st.cle)), dtype=st.dtype)
        it = brut.itemsize
        return np.lib.stride_tricks.as_strided(
            brut[decalage:], shape=taille, strides=[s * it for s in pas]).astype(np.float32)


def lire_pth(chemin):
    z = zipfile.ZipFile(chemin)
    pkl = [n for n in z.namelist() if n.endswith('/data.pkl')][0]
    prefixe = pkl[:-len('/data.pkl')]
    with z.open(pkl) as fh:
        d = _Lecteur(fh, z, prefixe).load()
    return d.get('params_ema') or d.get('params') or d


def modele_esrgan():
    """SRVGGNetCompact (realesr-general-x4v3) reconstruit avec OpenVINO."""
    ir = os.path.join(CACHE, 'realesr-general-x4v3.xml')
    if os.path.exists(ir):
        return core().read_model(ir)
    import openvino as ov
    from openvino import opset13 as op, opset11 as op11
    p = lire_pth(os.path.join(MODELES, 'esrgan', 'realesr-general-x4v3.pth'))
    x = op.parameter([1, 3, -1, -1], np.float32, name='image')
    h = x
    i = 0
    while 'body.%d.weight' % i in p:
        w = p['body.%d.weight' % i]
        if w.ndim == 4:
            h = op.convolution(h, op.constant(w), [1, 1], [1, 1], [1, 1], [1, 1])
            h = op.add(h, op.constant(p['body.%d.bias' % i].reshape(1, -1, 1, 1)))
        else:
            h = op.prelu(h, op.constant(w))
        i += 1
    h = op.depth_to_space(h, 'depth_first', 4)
    base = op11.interpolate(x, op.constant(np.array([4.0, 4.0], np.float32)), 'nearest', 'scales',
                            axes=op.constant(np.array([2, 3], np.int64)))
    m = ov.Model([op.add(h, base)], [x], 'realesr-general-x4v3')
    os.makedirs(CACHE, exist_ok=True)
    ov.save_model(m, ir)
    return m


def agrandir(im, tuile=256, marge=16):
    cm, dev = compiler('agrandir', modele_esrgan(), [1, 3, tuile + 2 * marge, tuile + 2 * marge])
    rgb, alpha = rgb_alpha(im)
    H, W = rgb.shape[:2]
    if H * W > 2500 * 2500:
        raise RuntimeError('image trop grande pour ×4 (maximum 2500 × 2500 pixels)')
    T = tuile + 2 * marge
    pad = np.pad(rgb, ((marge, marge + tuile), (marge, marge + tuile), (0, 0)), mode='reflect')
    out = np.zeros((H * 4, W * 4, 3), np.float32)
    for y in range(0, H, tuile):
        for x in range(0, W, tuile):
            t = pad[y:y + T, x:x + T].transpose(2, 0, 1)[None]
            r = cm(t)[0][0].transpose(1, 2, 0)
            hh, ww = min(tuile, H - y), min(tuile, W - x)
            out[y * 4:(y + hh) * 4, x * 4:(x + ww) * 4] = \
                r[marge * 4:(marge + hh) * 4, marge * 4:(marge + ww) * 4]
    if alpha is not None:
        alpha = alpha.resize((W * 4, H * 4), Image.BICUBIC)
    return out, alpha


# ----------------------------------------------------------------- créer ---
_t2i = None


def creer(texte, graine):
    global _t2i
    import openvino_genai as g
    if _t2i is None:
        chemin = os.path.join(MODELES, 'lcm')
        for dev in (['NPU'] if 'NPU' in core().available_devices else []) + ['CPU']:
            try:
                t0 = time.perf_counter()
                p = g.Text2ImagePipeline(chemin)
                p.reshape(1, 512, 512, p.get_generation_config().guidance_scale)
                p.compile(dev, config={'CACHE_DIR': CACHE})
                _t2i = (p, dev)
                dire(info='création d\'image prête sur %s en %.1f s' % (dev, time.perf_counter() - t0))
                break
            except Exception as e:
                dire(info='création d\'image : %s indisponible (%s)' % (dev, str(e)[:150]))
        if _t2i is None:
            raise RuntimeError('modèle de création d\'image impossible à charger')
    p, _dev = _t2i
    t = p.generate(texte, num_inference_steps=4, rng_seed=int(graine))
    return np.asarray(t.data)[0].astype(np.float32) / 255


# ------------------------------------------------------------- boucle ---
def traiter(q):
    """Une requête → une réponse (dict). Utilisé par main() et par aube-ia."""
    t0 = time.perf_counter()
    try:
        op = q['op']
        if op == 'ajuster':
            rgb, a = rgb_alpha(lire(q['src']))
            ecrire(ajuster(rgb, q.get('reglages', {})), a, q['dst'])
        elif op == 'auto':
            rgb, _a = rgb_alpha(lire(q['src']))
            return {'ok': True, 'reglages': auto(rgb), 'duree': round(time.perf_counter() - t0, 2)}
        elif op == 'fond':
            rgb, masque = fond(lire(q['src']))
            ecrire(rgb, masque, q['dst'])
        elif op == 'gomme':
            rgb, a = gomme(lire(q['src']), lire(q['masque']))
            ecrire(rgb, a, q['dst'])
        elif op == 'agrandir':
            rgb, a = agrandir(lire(q['src']))
            ecrire(rgb, a, q['dst'])
        elif op == 'creer':
            ecrire(creer(q['texte'], q.get('graine', 0)), None, q['dst'])
        else:
            raise RuntimeError('opération inconnue : %s' % op)
        return {'ok': True, 'op': op, 'dst': q.get('dst'), 'duree': round(time.perf_counter() - t0, 2)}
    except Exception as e:
        return {'erreur': str(e)[:400], 'op': q.get('op')}


def liberer():
    """Oublie les modèles compilés (mémoire rendue)."""
    global _t2i
    _compiles.clear()
    _t2i = None


def main():
    dire(etat='pret')
    for ligne in sys.stdin:
        try:
            q = json.loads(ligne)
        except ValueError:
            continue
        dire(**traiter(q))
    return 0


if __name__ == '__main__':
    sys.exit(main())
