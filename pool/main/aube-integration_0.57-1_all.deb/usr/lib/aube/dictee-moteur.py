"""Moteur de la Dictée d'Aube : Whisper (OpenVINO GenAI) sur le NPU Intel.

Lancé par aube-dictee avec le Python d'OpenVINO (/opt/aube/openvino) :
    python3 -I dictee-moteur.py MODELE CACHE
Échange des lignes JSON : il annonce {"etat": "pret", "appareil": ...}, puis
pour chaque {"audio": chemin, "langue": "fr"} reçu, répond {"texte": ...} ou
{"erreur": ...}. Le NPU est préféré ; sans NPU, le processeur prend le relais.
"""
import json, subprocess, sys, time


def dire(**kw):
    print(json.dumps(kw, ensure_ascii=False), flush=True)


def lire_audio(chemin):
    """N'importe quel fichier audio ou vidéo → 16 kHz mono, float32 (ffmpeg)."""
    import numpy as np
    brut = subprocess.run(
        ['ffmpeg', '-nostdin', '-v', 'error', '-i', chemin, '-vn', '-ac', '1', '-ar', '16000',
         '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(brut, dtype=np.float32)


def main():
    modele, cache = sys.argv[1], sys.argv[2]
    import openvino as ov
    import openvino_genai as g
    appareils = ov.Core().available_devices
    pipe, appareil = None, None
    for dev in (['NPU'] if 'NPU' in appareils else []) + ['CPU']:
        dire(etat='chargement', appareil=dev)
        try:
            t0 = time.perf_counter()
            pipe = g.WhisperPipeline(modele, dev, CACHE_DIR=cache)
            appareil = dev
            dire(etat='pret', appareil=dev, duree=round(time.perf_counter() - t0, 1))
            break
        except Exception as e:  # NPU indisponible : on essaie le processeur
            dire(etat='echec-appareil', appareil=dev, erreur=str(e)[:300])
    if pipe is None:
        dire(etat='erreur', erreur='Whisper ne se charge ni sur le NPU ni sur le processeur')
        return 1
    for ligne in sys.stdin:
        try:
            req = json.loads(ligne)
            audio = lire_audio(req['audio'])
            if audio.size < 1600:
                dire(texte='', duree_audio=0, duree=0)
                continue
            # Sur du silence, Whisper invente (« Sous-titrage Société
            # Radio-Canada ») : on prévient plutôt que d'écrire n'importe quoi.
            if float(abs(audio).max()) < 0.003:
                dire(erreur='aucun son capté (micro coupé ou absent ? '
                            'Menu › Son et vidéo › Contrôle du volume, onglet Périphériques d\'entrée)')
                continue
            t0 = time.perf_counter()
            r = pipe.generate(audio.tolist(), language='<|%s|>' % req.get('langue', 'fr'),
                              task='transcribe')
            dire(texte=str(r).strip(), appareil=appareil, duree_audio=round(audio.size / 16000, 1),
                 duree=round(time.perf_counter() - t0, 2))
        except subprocess.CalledProcessError as e:
            dire(erreur='fichier illisible : ' + e.stderr.decode(errors='replace')[:200])
        except Exception as e:
            dire(erreur=str(e)[:300])
    return 0


if __name__ == '__main__':
    sys.exit(main())
