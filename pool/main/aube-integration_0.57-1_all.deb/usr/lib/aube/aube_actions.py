"""Aube Linux : actions que l'Assistant a le droit de faire sur l'ordinateur.

Liste fermée, sur le modèle d'openKylin : le modèle de langage ne lance
jamais de commande lui-même, il demande une de ces actions avec des valeurs
qui sont vérifiées ici (bornes, choix permis) avant d'agir. Rien ne demande
de mot de passe ni ne sort du compte de l'utilisateur ; aucune action
n'efface quoi que ce soit.

    outils()              description des actions pour le modèle (format
                          « tools » d'OpenAI, lu par le gabarit de Qwen3)
    a_confirmer(nom, a)   texte de la question à poser avant d'agir, ou None
    executer(nom, a)      (réussi, message pour l'utilisateur et le modèle)
"""
import glob, json, os, shutil, subprocess, time

import gi
gi.require_version('Gio', '2.0')
from gi.repository import Gio, GLib

LUMINOSITE = '/sys/class/backlight'
DOSSIERS_CONF = os.path.expanduser('~/.config/aube/dossiers.json')
COULEURS = {
    'rouge': 'red', 'carmin': 'carmine', 'rose': 'pink', 'magenta': 'magenta', 'violet': 'violet',
    'indigo': 'indigo', 'bleu': 'blue', 'bleu gris': 'bluegrey', 'bleu canard': 'teal',
    'cyan': 'cyan', 'cyan foncé': 'darkcyan', 'vert': 'green', 'jaune': 'yellow',
    'orange': 'orange', 'orange foncé': 'deeporange', 'orange pâle': 'paleorange',
    'marron': 'brown', 'marron clair': 'palebrown', 'gris': 'grey', 'noir': 'black',
    'blanc': 'white',
}
THEMES = {'clair': 'Orchis-Light', 'sombre': 'Orchis-Dark'}
LECTURES = ('etat_systeme',)  # actions qui ne changent rien


def _cmd(*args, timeout=20):
    r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    if r.returncode:
        raise RuntimeError((r.stderr or r.stdout).strip()[:200] or 'échec de %s' % args[0])
    return r.stdout


def _xdg(nom):
    return {
        'Documents': GLib.UserDirectory.DIRECTORY_DOCUMENTS,
        'Images': GLib.UserDirectory.DIRECTORY_PICTURES,
        'Téléchargements': GLib.UserDirectory.DIRECTORY_DOWNLOAD,
        'Musique': GLib.UserDirectory.DIRECTORY_MUSIC,
        'Vidéos': GLib.UserDirectory.DIRECTORY_VIDEOS,
        'Bureau': GLib.UserDirectory.DIRECTORY_DESKTOP,
    }.get(nom)


def applications():
    """Applications visibles dans le menu : {nom affiché: AppInfo}."""
    apps = {}
    for a in Gio.AppInfo.get_all():
        if a.should_show() and a.get_display_name():
            apps.setdefault(a.get_display_name(), a)
    return apps


# ------------------------------------------------------------------ actions

def luminosite(pourcentage):
    dev = sorted(os.listdir(LUMINOSITE))[0]
    maxi = int(open(os.path.join(LUMINOSITE, dev, 'max_brightness')).read())
    # logind règle la luminosité de la session active sans mot de passe.
    _cmd('busctl', 'call', 'org.freedesktop.login1', '/org/freedesktop/login1/session/auto',
         'org.freedesktop.login1.Session', 'SetBrightness', 'ssu', 'backlight', dev,
         str(max(1, round(maxi * pourcentage / 100))))
    return 'Luminosité de l\'écran réglée à %d %%.' % pourcentage


def volume(pourcentage):
    _cmd('wpctl', 'set-mute', '@DEFAULT_AUDIO_SINK@', '0')
    _cmd('wpctl', 'set-volume', '@DEFAULT_AUDIO_SINK@', '%d%%' % pourcentage)
    return 'Volume réglé à %d %%.' % pourcentage


def son_coupe(coupe):
    _cmd('wpctl', 'set-mute', '@DEFAULT_AUDIO_SINK@', '1' if coupe else '0')
    return 'Son coupé.' if coupe else 'Son remis.'


def wifi(actif):
    _cmd('nmcli', 'radio', 'wifi', 'on' if actif else 'off')
    return 'Wi-Fi allumé.' if actif else 'Wi-Fi éteint.'


def bluetooth(actif):
    _cmd('bluetoothctl', 'power', 'on' if actif else 'off')
    return 'Bluetooth allumé.' if actif else 'Bluetooth éteint.'


def theme(mode):
    nom = THEMES[mode]
    _cmd('xfconf-query', '-c', 'xsettings', '-p', '/Net/ThemeName', '-s', nom)
    if os.path.isdir('/usr/share/themes/%s/xfwm4' % nom):
        _cmd('xfconf-query', '-c', 'xfwm4', '-p', '/general/theme', '-s', nom)
    return 'Thème %s appliqué.' % mode


def couleur_dossiers(couleur):
    code = COULEURS[couleur]
    try:
        forme = json.load(open(DOSSIERS_CONF)).get('forme', 'Papirus')
    except (OSError, ValueError):
        forme = 'Papirus'
    _cmd('aube-dossiers', '--appliquer', forme, code, timeout=180)
    # Le curseur suit la couleur des dossiers (choix d'Aube 0.21).
    try:
        _cmd('aube-dossiers', '--curseur', code, timeout=180)
    except RuntimeError:
        pass
    return 'Dossiers et curseur en %s.' % couleur


def trouver_application(nom):
    """Nom donné par l'utilisateur -> (nom affiché, AppInfo) ; nom exact,
    puis début du nom, puis nom contenu (sans tenir compte des majuscules)."""
    apps = applications()
    n = nom.strip().lower()
    for test in (lambda x: x == n, lambda x: x.startswith(n), lambda x: n in x):
        trouve = sorted((k for k in apps if test(k.lower())), key=len)
        if trouve:
            return trouve[0], apps[trouve[0]]
    raise ValueError('aucune application « %s »' % nom)


def ouvrir_application(nom):
    nom, app = trouver_application(nom)
    app.launch([], None)
    return '« %s » ouvert.' % nom


def ouvrir_dossier(dossier):
    if dossier == 'Corbeille':
        uri = 'trash:///'
    elif dossier == 'Dossier personnel':
        uri = GLib.filename_to_uri(GLib.get_home_dir())
    else:
        uri = GLib.filename_to_uri(GLib.get_user_special_dir(_xdg(dossier)) or GLib.get_home_dir())
    Gio.AppInfo.launch_default_for_uri(uri, None)
    return 'Dossier %s ouvert.' % dossier


def capture_ecran():
    dest = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES) or GLib.get_home_dir()
    # 2 s : le temps de laisser passer au premier plan la fenêtre à capturer.
    subprocess.Popen(['xfce4-screenshooter', '-f', '-d', '2', '-s', dest])
    return 'Capture de tout l\'écran dans 2 secondes, enregistrée dans %s.' % os.path.basename(dest)


def verrouiller():
    subprocess.Popen(['xflock4'])
    return 'Écran verrouillé.'


def etat_systeme():
    """Lecture seule : batterie, réseau, son, luminosité, mémoire, processeur,
    température, disque."""
    info = []
    try:
        bat = _cmd('upower', '-i', '/org/freedesktop/UPower/devices/battery_BAT0')
        d = dict(l.strip().split(':', 1) for l in bat.splitlines() if ':' in l)
        etat = {'charging': 'en charge', 'discharging': 'sur batterie',
                'fully-charged': 'chargée'}.get(d.get('state', '').strip(), d.get('state', '').strip())
        info.append('batterie %s (%s)' % (d.get('percentage', '?').strip(), etat))
    except (RuntimeError, OSError, ValueError):
        pass
    try:
        reseau = [l.split(':', 1)[1] for l in _cmd('nmcli', '-t', '-f', 'ACTIVE,SSID', 'dev', 'wifi', 'list', '--rescan', 'no').splitlines()
                  if l.startswith('yes:')]
        info.append('Wi-Fi : %s' % (reseau[0] if reseau else 'non connecté'))
    except (RuntimeError, OSError):
        pass
    try:
        v = _cmd('wpctl', 'get-volume', '@DEFAULT_AUDIO_SINK@').split()
        info.append('volume %d %%%s' % (round(float(v[1]) * 100), ' (coupé)' if 'MUTED' in ' '.join(v) else ''))
    except (RuntimeError, OSError, ValueError, IndexError):
        pass
    try:
        dev = sorted(os.listdir(LUMINOSITE))[0]
        b = int(open(os.path.join(LUMINOSITE, dev, 'brightness')).read())
        m = int(open(os.path.join(LUMINOSITE, dev, 'max_brightness')).read())
        info.append('luminosité %d %%' % round(100 * b / m))
    except (OSError, ValueError, IndexError):
        pass
    try:
        mem = dict(l.split(':', 1) for l in open('/proc/meminfo'))
        total, libre = (int(mem[k].split()[0]) / 1048576 for k in ('MemTotal', 'MemAvailable'))
        info.append(('mémoire vive %.1f Go utilisés sur %.0f Go (%.1f Go libres)'
                     % (total - libre, total, libre)).replace('.', ','))
    except (OSError, ValueError, KeyError):
        pass
    try:
        def compteurs():
            v = [int(x) for x in open('/proc/stat').readline().split()[1:]]
            return sum(v), v[3] + v[4]          # total, inactif (idle + iowait)
        (t1, i1), _ = compteurs(), time.sleep(0.3)
        t2, i2 = compteurs()
        info.append('processeur utilisé à %d %%' % round(100 * (1 - (i2 - i1) / max(1, t2 - t1))))
    except (OSError, ValueError):
        pass
    for z in sorted(glob.glob('/sys/class/thermal/thermal_zone*')):
        try:
            if open(z + '/type').read().strip() == 'x86_pkg_temp':
                info.append('température du processeur %d °C' % round(int(open(z + '/temp').read()) / 1000))
                break
        except (OSError, ValueError):
            pass
    du = shutil.disk_usage(GLib.get_home_dir())
    info.append('espace libre %.0f Go sur %.0f Go' % (du.free / 1e9, du.total / 1e9))
    return 'État : ' + ', '.join(info) + '.'


# --------------------------------------------------------------- catalogue

def _p(type_, desc, **kw):
    return dict(type=type_, description=desc, **kw)


def _catalogue():
    return {
        'luminosite': (luminosite, 'Régler la luminosité de l\'écran.',
                       {'pourcentage': _p('integer', 'de 5 à 100', minimum=5, maximum=100)}),
        'volume': (volume, 'Régler le volume du son.',
                   {'pourcentage': _p('integer', 'de 0 à 100', minimum=0, maximum=100)}),
        'son_coupe': (son_coupe, 'Couper ou remettre le son.',
                      {'coupe': _p('boolean', 'true pour couper, false pour remettre')}),
        'wifi': (wifi, 'Allumer ou éteindre le Wi-Fi.', {'actif': _p('boolean', 'true = allumé')}),
        'bluetooth': (bluetooth, 'Allumer ou éteindre le Bluetooth.',
                      {'actif': _p('boolean', 'true = allumé')}),
        'theme': (theme, 'Passer le bureau en thème clair ou sombre.',
                  {'mode': _p('string', 'clair ou sombre', enum=list(THEMES))}),
        'couleur_dossiers': (couleur_dossiers, 'Changer la couleur des dossiers (et du curseur).',
                             {'couleur': _p('string', 'couleur', enum=list(COULEURS))}),
        'ouvrir_application': (ouvrir_application, 'Ouvrir une application installée.',
                               {'nom': _p('string', 'nom de l\'application, par exemple '
                                          'Plexamp, Photo, Microsoft Edge, LibreOffice Writer')}),
        'ouvrir_dossier': (ouvrir_dossier, 'Ouvrir un dossier dans le gestionnaire de fichiers.',
                           {'dossier': _p('string', 'dossier', enum=[
                               'Dossier personnel', 'Documents', 'Images', 'Téléchargements',
                               'Musique', 'Vidéos', 'Bureau', 'Corbeille'])}),
        'capture_ecran': (capture_ecran, 'Faire une capture de tout l\'écran (dans Images).', {}),
        'verrouiller': (verrouiller, 'Verrouiller l\'écran.', {}),
        'etat_systeme': (etat_systeme, 'Lire l\'état du PC : batterie, Wi-Fi, volume, luminosité, '
                                       'mémoire vive (RAM), utilisation et température du '
                                       'processeur, espace disque libre.', {}),
    }


_CAT = None


def catalogue():
    global _CAT
    if _CAT is None:
        _CAT = _catalogue()
    return _CAT


def outils():
    return [{'type': 'function', 'function': {
        'name': nom, 'description': desc,
        'parameters': {'type': 'object', 'properties': props, 'required': list(props)}}}
        for nom, (_f, desc, props) in catalogue().items()]


def verifier(nom, args):
    """Arguments validés et convertis ; ValueError si refusés."""
    if nom not in catalogue():
        raise ValueError('action inconnue : %s' % nom)
    _f, _d, props = catalogue()[nom]
    args = args if isinstance(args, dict) else {}
    propres = {}
    for cle, sch in props.items():
        if cle not in args:
            raise ValueError('valeur manquante : %s' % cle)
        v = args[cle]
        if sch['type'] == 'integer':
            v = int(round(float(v)))
            if not sch['minimum'] <= v <= sch['maximum']:
                raise ValueError('%s hors limites (%d à %d)' % (cle, sch['minimum'], sch['maximum']))
        elif sch['type'] == 'boolean':
            if isinstance(v, str):
                v = v.strip().lower() in ('true', 'oui', '1', 'on')
            v = bool(v)
        elif 'enum' not in sch:
            v = str(v).strip()[:80]
            if not v:
                raise ValueError('valeur vide : %s' % cle)
        else:
            v = str(v).strip()
            permis = {e.lower(): e for e in sch['enum']}
            if v.lower() not in permis:
                raise ValueError('choix non permis pour %s : %s' % (cle, v))
            v = permis[v.lower()]
        propres[cle] = v
    return propres


def a_confirmer(nom, args):
    if nom == 'wifi' and not args.get('actif'):
        return 'Éteindre le Wi-Fi ? Internet, le VPN et le NAS seront coupés.'
    return None


def executer(nom, args):
    try:
        args = verifier(nom, args)
        return True, catalogue()[nom][0](**args)
    except Exception as e:  # message rendu au modèle et à l'utilisateur
        return False, 'Action « %s » impossible : %s' % (nom, e)
