"""Aube Linux : accès au moteur d'IA commun (aube-ia) depuis les applications.

    demander({"op": …})   une requête, une réponse (dict)
    Conversation(outils)  connexion de l'Assistant : .stdin / .stdout comme
                          un processus, .terminate() pour la fermer
Le moteur est démarré s'il ne répond pas (il charge ses modèles à la demande).
"""
import json, os, socket, subprocess, tempfile, time

OV_PY = os.environ.get('AUBE_OV_PY', '/opt/aube/openvino/bin/python3')
SERVICE = os.environ.get('AUBE_IA', '/usr/lib/aube/aube-ia.py')


def prise():
    return os.path.join(os.environ.get('XDG_RUNTIME_DIR') or tempfile.gettempdir(), 'aube-ia.sock')


def connecter(delai=None):
    """Socket connecté au moteur ; le démarre au besoin (jusqu'à 30 s)."""
    def essai():
        s = socket.socket(socket.AF_UNIX)
        s.settimeout(delai)
        s.connect(prise())
        return s
    try:
        return essai()
    except OSError:
        subprocess.Popen([OV_PY, '-I', SERVICE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    for _ in range(150):
        time.sleep(0.2)
        try:
            return essai()
        except OSError:
            pass
    raise OSError('le moteur d\'IA commun ne démarre pas')


def demander(req, delai=300):
    s = connecter(delai)
    try:
        s.sendall((json.dumps(req, ensure_ascii=False) + '\n').encode())
        rep = b''
        while not rep.endswith(b'\n'):
            bloc = s.recv(1 << 20)
            if not bloc:
                break
            rep += bloc
    finally:
        s.close()
    return json.loads(rep or b'{}')


class Conversation:
    """Conversation de l'Assistant, avec la même interface qu'un processus."""

    def __init__(self, outils):
        self.s = connecter()
        self.stdin = self.s.makefile('w', encoding='utf-8')
        self.stdout = self.s.makefile('r', encoding='utf-8')
        self.stdin.write(json.dumps({'op': 'assistant', 'outils': outils}, ensure_ascii=False) + '\n')
        self.stdin.flush()

    def terminate(self):
        try:
            self.s.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.s.close()
